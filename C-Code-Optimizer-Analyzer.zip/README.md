# Final Year Compiler Design Project: C-Code Optimizer and Analyzer

An interactive full-stack compiler analysis and optimization system. Users can enter C code into a web-based Monaco editor and visualize the output of all standard compiler front-end and mid-end phases in real time.

---

## Key Features

1. **Lexical Analysis (Tokenization)**: Complete regex-based tokenizer that maps character sequences into token streams with types (Keywords, Identifiers, Numbers, Operators, Punctuation, Comments) and source line/column positions.
2. **Syntax Analysis**: Recursive descent parser that processes a subset of standard C (variable declarations, arithmetic expressions, function boundaries, loops, conditionals) and visualizes a collapsible AST hierarchy and tree nodes.
3. **Three-Address Code (TAC) & Quadruples**: Generates intermediate flat TAC representation and outputs a structured quadruple instruction set (`op`, `arg1`, `arg2`, `result`).
4. **Optimization Engine (8 Passes)**:
   - *Constant Folding*: Algebraic simplification of numeric literal calculations.
   - *Constant Propagation*: In-scope replacement of variables with known literal constants.
   - *Copy Propagation*: Direct propagation of duplicated variables to reduce register pressures.
   - *Dead Code Elimination*: Deletes unreachable branch conditions (`if(0)`) and statements after return blocks.
   - *Common Subexpression Elimination (CSE)*: Combines redundant duplicate expressions.
   - *Loop Optimization (LICM)*: Hoists invariant calculations out of loop statements.
   - *Strength Reduction*: Simplifies multiplication/division by powers of 2 into bit-shifts.
   - *Unused Variable Removal*: Discards declared/assigned variables that are never read.
5. **Algorithm Generator**: Translates code structure into natural step-by-step algorithms.
6. **Flowchart Renderer**: Automatically builds interactive SVGs from control flow diagrams, with PNG/SVG export downloads.
7. **Complexity Analyzer**: Calculates Loop Count, Maximum Loop Nest depth, Recursion detection, and estimates theoretical Time and Space Complexity in Big-O notations.
8. **Optimization Reports**: Generates detailed, vector-drawn PDF reports containing code comparison, token tables, tree structures, and flowcharts.

---

## Technology Stack

- **Frontend**: React (Vite SPA), TailwindCSS, Monaco Code Editor, Mermaid.js (graph diagrams), Lucide Icons, Canvas Confetti.
- **Backend**: Node.js, Express, PDFKit (PDF rendering engine).
- **Orchestration**: Docker & Docker Compose.

---

## Project Structure

```text
c-code-optimizer-analyzer/
├── backend/
│   ├── compiler/          # Compiler pipeline modules
│   │   ├── lexer.js
│   │   ├── parser.js
│   │   ├── optimizer.js
│   │   ├── tac.js
│   │   ├── complexity.js
│   │   ├── algorithm.js
│   │   └── flowchart.js
│   ├── routes/
│   │   └── analyze.js     # Analysis routes
│   ├── utils/
│   │   └── pdfGenerator.js # PDF report rendering
│   ├── package.json
│   ├── server.js          # Express app entrypoint
│   └── test.js            # Compiler test suite
├── frontend/
│   ├── src/
│   │   ├── components/    # Monaco editor, tabs, charts
│   │   ├── App.jsx        # Main dashboard state coordinate
│   │   ├── index.css      # Core styles & Tailwind directives
│   │   └── main.jsx
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── package.json
│   └── index.html
├── samples/               # Demo C files for validation
├── Dockerfile.backend
├── Dockerfile.frontend
├── docker-compose.yml
├── README.md
└── INSTALL.md
```

---

## Getting Started

Refer to [INSTALL.md](file:///C:/Users/bisht/.gemini/antigravity-ide/scratch/c-code-optimizer-analyzer/INSTALL.md) for detailed manual execution commands, test running, and Docker environment setups.
