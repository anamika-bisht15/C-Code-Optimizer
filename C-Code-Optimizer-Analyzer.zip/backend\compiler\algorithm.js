/**
 * Algorithm Generator
 * For C-Code Optimizer and Analyzer
 * Translates C AST structures into natural language step-by-step algorithms.
 */

const { generateCode } = require('./optimizer');

function generateAlgorithm(ast) {
  const steps = [];
  let stepCounter = 1;

  const addStep = (desc) => {
    steps.push({
      step: `Step ${stepCounter++}`,
      description: desc
    });
  };

  addStep('Start of program');

  const processNode = (node) => {
    if (!node) return;

    switch (node.type) {
      case 'FunctionDeclaration':
        const params = node.params.map(p => p.name).join(', ');
        addStep(`Define function '${node.name}' taking inputs (${params || 'none'})`);
        node.body.statements.forEach(processNode);
        addStep(`End of function '${node.name}'`);
        break;

      case 'VariableDeclaration': {
        const initVal = node.init ? generateCode(node.init) : 'default value';
        addStep(`Declare variable '${node.name}' of type '${node.dataType}' and initialize it to ${initVal}`);
        break;
      }

      case 'Assignment': {
        const expr = generateCode(node.value);
        addStep(`Evaluate expression (${expr}) and store result in variable '${node.name}'`);
        break;
      }

      case 'ExpressionStatement':
        if (node.expression.type === 'Assignment') {
          processNode(node.expression);
        } else {
          const expr = generateCode(node.expression);
          addStep(`Evaluate statement: ${expr}`);
        }
        break;

      case 'IfStatement': {
        const cond = generateCode(node.condition);
        addStep(`Check if (${cond})`);
        
        // Save current stepCounter to indentation context if needed, or format inline
        const hasElse = !!node.elseBranch;
        
        addStep(`Branch A: If condition is true, then:`);
        if (node.thenBranch.type === 'Block') {
          node.thenBranch.statements.forEach(processNode);
        } else {
          processNode(node.thenBranch);
        }
        
        if (hasElse) {
          addStep(`Branch B: Otherwise (if condition is false), then:`);
          if (node.elseBranch.type === 'Block') {
            node.elseBranch.statements.forEach(processNode);
          } else {
            processNode(node.elseBranch);
          }
        }
        addStep(`End of condition check if (${cond})`);
        break;
      }

      case 'WhileStatement': {
        const cond = generateCode(node.condition);
        addStep(`Begin loop: Repeat while (${cond}) is true`);
        if (node.body.type === 'Block') {
          node.body.statements.forEach(processNode);
        } else {
          processNode(node.body);
        }
        addStep(`Loop repeat condition: Go back and check if (${cond})`);
        addStep(`End of loop while (${cond})`);
        break;
      }

      case 'ForStatement': {
        const initCode = node.init ? generateCode(node.init).trim().replace(';', '') : 'none';
        const cond = node.condition ? generateCode(node.condition) : 'true';
        const update = node.update ? generateCode(node.update).replace(';', '') : 'none';

        addStep(`Begin for-loop: Initialize (${initCode})`);
        addStep(`Check loop condition: Continue if (${cond}) is true`);
        
        if (node.body.type === 'Block') {
          node.body.statements.forEach(processNode);
        } else {
          processNode(node.body);
        }

        addStep(`Perform loop update step: (${update})`);
        addStep(`Loop repeat condition: Go back and check if (${cond})`);
        addStep(`End of for-loop`);
        break;
      }

      case 'ReturnStatement': {
        const val = node.value ? generateCode(node.value) : 'void';
        addStep(`Return ${val} and exit function`);
        break;
      }

      case 'BreakStatement':
        addStep('Exit the current loop immediately (break)');
        break;

      case 'ContinueStatement':
        addStep('Skip remaining steps and jump to next loop iteration (continue)');
        break;
    }
  };

  // Process the program AST body
  if (ast && ast.body) {
    ast.body.forEach(processNode);
  }

  addStep('Stop of program');

  return steps;
}

module.exports = { generateAlgorithm };
