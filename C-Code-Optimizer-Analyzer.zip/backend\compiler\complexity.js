/**
 * Complexity Analyzer
 * For C-Code Optimizer and Analyzer
 * Analyzes loops, nested loops, recursion, and estimates Time & Space Complexity.
 */

function analyzeComplexity(ast) {
  let loopCount = 0;
  let maxNestingDepth = 0;
  let recursionDetected = false;
  const functions = [];

  // 1. Walk the AST to find functions and inspect them
  const walk = (node, currentLoopDepth = 0, currentFunc = null) => {
    if (!node) return;

    let isLoop = node.type === 'WhileStatement' || node.type === 'ForStatement';
    let nextLoopDepth = currentLoopDepth;

    if (isLoop) {
      loopCount++;
      nextLoopDepth = currentLoopDepth + 1;
      if (nextLoopDepth > maxNestingDepth) {
        maxNestingDepth = nextLoopDepth;
      }
    }

    let nextFunc = currentFunc;
    if (node.type === 'FunctionDeclaration') {
      nextFunc = node.name;
      functions.push({
        name: node.name,
        hasRecursion: false,
        maxNesting: 0,
        loopCount: 0,
        variablesCount: 0,
        arraysCount: 0
      });
    }

    if (node.type === 'FunctionCall' && currentFunc && node.name === currentFunc) {
      recursionDetected = true;
      const fInfo = functions.find(f => f.name === currentFunc);
      if (fInfo) fInfo.hasRecursion = true;
    }

    if (node.type === 'VariableDeclaration' && currentFunc) {
      const fInfo = functions.find(f => f.name === currentFunc);
      if (fInfo) {
        fInfo.variablesCount++;
        // If variable declaration indicates an array (future extension)
        if (node.dataType.includes('[') || (node.init && node.init.type === 'ArrayExpression')) {
          fInfo.arraysCount++;
        }
      }
    }

    // Update function specific stats
    if (isLoop && currentFunc) {
      const fInfo = functions.find(f => f.name === currentFunc);
      if (fInfo) {
        fInfo.loopCount++;
        if (nextLoopDepth > fInfo.maxNesting) {
          fInfo.maxNesting = nextLoopDepth;
        }
      }
    }

    // Traverse children
    for (const key in node) {
      if (node[key] && typeof node[key] === 'object') {
        if (Array.isArray(node[key])) {
          node[key].forEach(child => walk(child, nextLoopDepth, nextFunc));
        } else {
          walk(node[key], nextLoopDepth, nextFunc);
        }
      }
    }
  };

  walk(ast);

  // 2. Estimate Time Complexity (Big O)
  // Let's analyze loop updates to distinguish O(n) from O(log n)
  const loopTypes = [];
  const findLoopTypes = (node) => {
    if (!node) return;
    if (node.type === 'WhileStatement' || node.type === 'ForStatement') {
      const updateExpr = node.type === 'ForStatement' ? node.update : null;
      let isLogarithmic = false;

      // If we find multiplication or division or bit shifts in update, it's logarithmic
      if (updateExpr) {
        const updateStr = JSON.stringify(updateExpr);
        if (updateStr.includes('*') || updateStr.includes('/') || updateStr.includes('<<') || updateStr.includes('>>')) {
          isLogarithmic = true;
        }
      }
      
      // Also scan while loop body for logarithmic updates
      if (node.type === 'WhileStatement') {
        const bodyStr = JSON.stringify(node.body);
        if (bodyStr.includes('*=') || bodyStr.includes('/=') || bodyStr.includes('>>=') || bodyStr.includes('<<=')) {
          isLogarithmic = true;
        }
      }

      loopTypes.push(isLogarithmic ? 'log n' : 'n');
    }

    for (const key in node) {
      if (node[key] && typeof node[key] === 'object') {
        if (Array.isArray(node[key])) {
          node[key].forEach(findLoopTypes);
        } else {
          findLoopTypes(node[key]);
        }
      }
    }
  };
  findLoopTypes(ast);

  // Determine Time Complexity
  let timeComplexity = 'O(1)';
  if (recursionDetected) {
    // Standard estimation for recursive function
    timeComplexity = loopCount > 0 ? 'O(2^n)' : 'O(n)';
  } else if (maxNestingDepth === 0) {
    timeComplexity = 'O(1)';
  } else if (maxNestingDepth === 1) {
    if (loopTypes.includes('log n') && !loopTypes.includes('n')) {
      timeComplexity = 'O(log n)';
    } else {
      timeComplexity = 'O(n)';
    }
  } else if (maxNestingDepth === 2) {
    if (loopTypes.filter(t => t === 'log n').length === 2) {
      timeComplexity = 'O((log n)²)';
    } else if (loopTypes.includes('log n') && loopTypes.includes('n')) {
      timeComplexity = 'O(n log n)';
    } else {
      timeComplexity = 'O(n²)';
    }
  } else if (maxNestingDepth === 3) {
    timeComplexity = 'O(n³)';
  } else {
    timeComplexity = `O(n^${maxNestingDepth})`;
  }

  // Determine Space Complexity
  let spaceComplexity = 'O(1)';
  if (recursionDetected) {
    // Call stack depth is O(n)
    spaceComplexity = 'O(n)';
  } else {
    // If any arrays or large local variable lists exist
    const hasArrays = functions.some(f => f.arraysCount > 0);
    spaceComplexity = hasArrays ? 'O(n)' : 'O(1)';
  }

  return {
    loopCount,
    maxNestingDepth,
    recursionDetected,
    timeComplexity,
    spaceComplexity,
    functions
  };
}

module.exports = { analyzeComplexity };
