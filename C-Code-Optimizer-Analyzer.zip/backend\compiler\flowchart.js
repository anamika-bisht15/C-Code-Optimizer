/**
 * Flowchart Generator
 * For C-Code Optimizer and Analyzer
 * Translates C AST structures into Graphviz DOT and Mermaid.js flowcharts.
 */

const { generateCode } = require('./optimizer');

class FlowchartGenerator {
  constructor() {
    this.nodes = []; // { id, label, shape, type }
    this.edges = []; // { from, to, label }
    this.nodeCounter = 1;
  }

  newNodeId() {
    return `node_${this.nodeCounter++}`;
  }

  addNode(label, type) {
    const id = this.newNodeId();
    let shape = 'box'; // default
    if (type === 'start' || type === 'end') shape = 'ellipse';
    else if (type === 'decision') shape = 'diamond';
    else if (type === 'io') shape = 'parallelogram';
    
    this.nodes.push({ id, label, shape, type });
    return id;
  }

  addEdge(from, to, label = '') {
    this.edges.push({ from, to, label });
  }

  generate(ast) {
    const startId = this.addNode('Start', 'start');
    
    // Process statements recursively and return the final node IDs
    const lastNode = this.processBlock(ast.body, startId);

    const endId = this.addNode('End', 'end');
    if (lastNode) {
      this.addEdge(lastNode, endId);
    } else {
      this.addEdge(startId, endId);
    }

    return {
      nodes: this.nodes,
      edges: this.edges,
      mermaid: this.toMermaid(),
      dot: this.toDot()
    };
  }

  processBlock(statements, prevNodeId) {
    let currentPrev = prevNodeId;
    if (!statements || statements.length === 0) return currentPrev;

    for (const stmt of statements) {
      currentPrev = this.processStatement(stmt, currentPrev);
    }
    return currentPrev;
  }

  processStatement(stmt, prevNodeId) {
    if (!stmt) return prevNodeId;

    switch (stmt.type) {
      case 'VariableDeclaration': {
        const initVal = stmt.init ? ` = ${generateCode(stmt.init)}` : '';
        const id = this.addNode(`Declare ${stmt.dataType} ${stmt.name}${initVal}`, 'process');
        this.addEdge(prevNodeId, id);
        return id;
      }

      case 'Assignment': {
        const expr = generateCode(stmt.value);
        const id = this.addNode(`${stmt.name} = ${expr}`, 'process');
        this.addEdge(prevNodeId, id);
        return id;
      }

      case 'ExpressionStatement':
        if (stmt.expression.type === 'Assignment') {
          return this.processStatement(stmt.expression, prevNodeId);
        } else if (stmt.expression.type === 'FunctionCall') {
          const id = this.addNode(`Call ${generateCode(stmt.expression)}`, 'io');
          this.addEdge(prevNodeId, id);
          return id;
        } else {
          const id = this.addNode(generateCode(stmt.expression), 'process');
          this.addEdge(prevNodeId, id);
          return id;
        }

      case 'IfStatement': {
        const condStr = generateCode(stmt.condition);
        const decId = this.addNode(`Is ${condStr}?`, 'decision');
        this.addEdge(prevNodeId, decId);

        // Then branch
        const thenStmts = stmt.thenBranch.type === 'Block' ? stmt.thenBranch.statements : [stmt.thenBranch];
        const lastThenId = this.processBlock(thenStmts, decId);
        this.edges[this.edges.length - 1].label = 'Yes'; // Label the first edge out of decision

        // Else branch
        let lastElseId = decId;
        if (stmt.elseBranch) {
          const elseStmts = stmt.elseBranch.type === 'Block' ? stmt.elseBranch.statements : [stmt.elseBranch];
          lastElseId = this.processBlock(elseStmts, decId);
          // find the edge connecting decId to first else block node and label it 'No'
          const edge = this.edges.find(e => e.from === decId && e.label === '');
          if (edge) edge.label = 'No';
        }

        // Join node
        const joinId = this.addNode('Join', 'process');
        
        // Link then branch to join
        if (lastThenId && lastThenId !== decId) {
          this.addEdge(lastThenId, joinId);
        } else {
          this.addEdge(decId, joinId, 'Yes');
        }

        // Link else branch to join
        if (lastElseId && lastElseId !== decId) {
          this.addEdge(lastElseId, joinId);
        } else {
          this.addEdge(decId, joinId, 'No');
        }

        return joinId;
      }

      case 'WhileStatement': {
        const condStr = generateCode(stmt.condition);
        const decId = this.addNode(`Loop: ${condStr}?`, 'decision');
        this.addEdge(prevNodeId, decId);

        // Loop body
        const bodyStmts = stmt.body.type === 'Block' ? stmt.body.statements : [stmt.body];
        const lastBodyId = this.processBlock(bodyStmts, decId);
        
        // Label the loop entry edge
        const entryEdge = this.edges.find(e => e.from === decId && e.to !== decId && e.label === '');
        if (entryEdge) entryEdge.label = 'Yes';

        // Loop back to decision
        if (lastBodyId && lastBodyId !== decId) {
          this.addEdge(lastBodyId, decId);
        }

        // Exit edge
        const exitNodeId = this.addNode('Exit Loop', 'process');
        this.addEdge(decId, exitNodeId, 'No');

        return exitNodeId;
      }

      case 'ForStatement': {
        // Init
        let initId = prevNodeId;
        if (stmt.init) {
          initId = this.processStatement(stmt.init, prevNodeId);
        }

        const condStr = stmt.condition ? generateCode(stmt.condition) : 'true';
        const decId = this.addNode(`For: ${condStr}?`, 'decision');
        this.addEdge(initId, decId);

        // Body
        const bodyStmts = stmt.body.type === 'Block' ? stmt.body.statements : [stmt.body];
        
        // We evaluate update after body
        const lastBodyId = this.processBlock(bodyStmts, decId);
        
        // Label the entry edge
        const entryEdge = this.edges.find(e => e.from === decId && e.to !== decId && e.label === '');
        if (entryEdge) entryEdge.label = 'Yes';

        let lastNode = lastBodyId;
        if (stmt.update) {
          const updId = this.addNode(`Update: ${generateCode(stmt.update).replace(';', '')}`, 'process');
          this.addEdge(lastBodyId, updId);
          lastNode = updId;
        }

        // Loop back to decision
        if (lastNode && lastNode !== decId) {
          this.addEdge(lastNode, decId);
        }

        // Exit loop
        const exitNodeId = this.addNode('Exit Loop', 'process');
        this.addEdge(decId, exitNodeId, 'No');

        return exitNodeId;
      }

      case 'FunctionDeclaration': {
        const id = this.addNode(`Function ${stmt.name}`, 'start');
        this.addEdge(prevNodeId, id);
        const lastBody = this.processBlock(stmt.body.statements, id);
        const endId = this.addNode(`Return from ${stmt.name}`, 'end');
        this.addEdge(lastBody, endId);
        return endId;
      }

      case 'ReturnStatement': {
        const val = stmt.value ? ` ${generateCode(stmt.value)}` : '';
        const id = this.addNode(`Return${val}`, 'io');
        this.addEdge(prevNodeId, id);
        return id;
      }

      case 'BreakStatement': {
        const id = this.addNode('Break', 'process');
        this.addEdge(prevNodeId, id);
        return id;
      }

      case 'ContinueStatement': {
        const id = this.addNode('Continue', 'process');
        this.addEdge(prevNodeId, id);
        return id;
      }

      default:
        return prevNodeId;
    }
  }

  toMermaid() {
    let m = 'graph TD\n';
    
    // Nodes definition
    this.nodes.forEach(n => {
      let shapeLeft = '[';
      let shapeRight = ']';
      if (n.shape === 'ellipse') {
        shapeLeft = '([';
        shapeRight = '])';
      } else if (n.shape === 'diamond') {
        shapeLeft = '{';
        shapeRight = '}';
      } else if (n.shape === 'parallelogram') {
        shapeLeft = '[/';
        shapeRight = '/]';
      }
      
      // Escape double quotes in label
      const safeLabel = n.label.replace(/"/g, '\\"');
      m += `    ${n.id}${shapeLeft}"${safeLabel}"${shapeRight}\n`;
    });

    // Edges definition
    this.edges.forEach(e => {
      if (e.label) {
        m += `    ${e.from} -->|${e.label}| ${e.to}\n`;
      } else {
        m += `    ${e.from} --> ${e.to}\n`;
      }
    });

    return m;
  }

  toDot() {
    let d = 'digraph G {\n';
    d += '    node [fontname="Helvetica", fontsize=11, shape=box, style=filled, fillcolor="#f9f9f9", color="#cccccc"];\n';
    d += '    edge [fontname="Helvetica", fontsize=9, color="#666666"];\n';

    this.nodes.forEach(n => {
      let shapeAttr = 'box';
      let fillcolor = '#ffffff';
      if (n.shape === 'ellipse') {
        shapeAttr = 'ellipse';
        fillcolor = '#e1f5fe'; // light blue for start/end
      } else if (n.shape === 'diamond') {
        shapeAttr = 'diamond';
        fillcolor = '#fff9c4'; // light yellow for decisions
      } else if (n.shape === 'parallelogram') {
        shapeAttr = 'parallelogram';
        fillcolor = '#e8f5e9'; // light green for I/O
      }
      
      const safeLabel = n.label.replace(/"/g, '\\"');
      d += `    ${n.id} [label="${safeLabel}", shape=${shapeAttr}, fillcolor="${fillcolor}"];\n`;
    });

    this.edges.forEach(e => {
      if (e.label) {
        d += `    ${e.from} -> ${e.to} [label="${e.label}"];\n`;
      } else {
        d += `    ${e.from} -> ${e.to};\n`;
      }
    });

    d += '}';
    return d;
  }
}

function generateFlowchart(ast) {
  const gen = new FlowchartGenerator();
  return gen.generate(ast);
}

module.exports = { generateFlowchart, FlowchartGenerator };
