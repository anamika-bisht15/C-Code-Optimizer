/**
 * Lexer for C-Code Optimizer and Analyzer
 * Tokenizes standard C constructs and produces a token stream with line numbers.
 */

const KEYWORDS = new Set([
  'int', 'float', 'double', 'char', 'void',
  'if', 'else', 'while', 'for', 'return',
  'break', 'continue', 'struct', 'switch', 'case', 'default'
]);

const OPERATORS = [
  '==', '!=', '<=', '>=', '&&', '||', '<<', '>>', '++', '--',
  '+', '-', '*', '/', '%', '=', '<', '>', '&', '|', '^', '!', '~'
];

// Sort operators by length descending so that multi-character operators (like ==) match before single-character ones (like =)
OPERATORS.sort((a, b) => b.length - a.length);

class Token {
  constructor(type, value, line, column) {
    this.type = type;     // KEYWORD, IDENTIFIER, NUMBER, OPERATOR, PUNCTUATION, STRING, COMMENT
    this.value = value;
    this.line = line;
    this.column = column;
  }
}

function tokenize(sourceCode) {
  const tokens = [];
  let index = 0;
  let line = 1;
  let column = 1;
  const length = sourceCode.length;

  while (index < length) {
    const char = sourceCode[index];

    // Handle newlines
    if (char === '\n') {
      line++;
      column = 1;
      index++;
      continue;
    }

    // Handle whitespace
    if (/\s/.test(char)) {
      index++;
      column++;
      continue;
    }

    // Handle single-line and multi-line comments
    if (char === '/' && index + 1 < length) {
      if (sourceCode[index + 1] === '/') {
        // Single-line comment
        let commentValue = '';
        index += 2;
        column += 2;
        while (index < length && sourceCode[index] !== '\n') {
          commentValue += sourceCode[index];
          index++;
          column++;
        }
        tokens.push(new Token('COMMENT', '//' + commentValue, line, column - commentValue.length - 2));
        continue;
      } else if (sourceCode[index + 1] === '*') {
        // Multi-line comment
        let commentValue = '';
        const startLine = line;
        const startCol = column;
        index += 2;
        column += 2;
        while (index < length) {
          if (sourceCode[index] === '*' && index + 1 < length && sourceCode[index + 1] === '/') {
            index += 2;
            column += 2;
            break;
          }
          if (sourceCode[index] === '\n') {
            line++;
            column = 1;
          } else {
            column++;
          }
          commentValue += sourceCode[index];
          index++;
        }
        tokens.push(new Token('COMMENT', '/*' + commentValue + '*/', startLine, startCol));
        continue;
      }
    }

    // Handle String Literals
    if (char === '"') {
      let stringValue = '';
      const startCol = column;
      index++; // consume opening quote
      column++;
      while (index < length && sourceCode[index] !== '"') {
        if (sourceCode[index] === '\\' && index + 1 < length) {
          stringValue += sourceCode[index] + sourceCode[index + 1];
          index += 2;
          column += 2;
        } else {
          stringValue += sourceCode[index];
          index++;
          column++;
        }
      }
      if (index < length && sourceCode[index] === '"') {
        index++; // consume closing quote
        column++;
      }
      tokens.push(new Token('STRING', `"${stringValue}"`, line, startCol));
      continue;
    }

    // Handle Numeric Literals (Integers, Decimals, Hexadecimals)
    if (/\d/.test(char) || (char === '.' && index + 1 < length && /\d/.test(sourceCode[index + 1]))) {
      let numberValue = '';
      const startCol = column;
      
      // Hexadecimal support
      if (char === '0' && index + 1 < length && (sourceCode[index + 1] === 'x' || sourceCode[index + 1] === 'X')) {
        numberValue += sourceCode[index] + sourceCode[index + 1];
        index += 2;
        column += 2;
        while (index < length && /[0-9a-fA-F]/.test(sourceCode[index])) {
          numberValue += sourceCode[index];
          index++;
          column++;
        }
      } else {
        let hasDecimal = false;
        while (index < length) {
          const c = sourceCode[index];
          if (c === '.') {
            if (hasDecimal) break; // Only one decimal allowed
            hasDecimal = true;
          } else if (!/\d/.test(c)) {
            break;
          }
          numberValue += c;
          index++;
          column++;
        }
      }
      tokens.push(new Token('NUMBER', numberValue, line, startCol));
      continue;
    }

    // Handle Identifiers and Keywords
    if (/[a-zA-Z_]/.test(char)) {
      let identValue = '';
      const startCol = column;
      while (index < length && /[a-zA-Z0-9_]/.test(sourceCode[index])) {
        identValue += sourceCode[index];
        index++;
        column++;
      }
      const type = KEYWORDS.has(identValue) ? 'KEYWORD' : 'IDENTIFIER';
      tokens.push(new Token(type, identValue, line, startCol));
      continue;
    }

    // Handle Operators (match longest first)
    let operatorMatched = false;
    for (const op of OPERATORS) {
      if (sourceCode.substring(index, index + op.length) === op) {
        tokens.push(new Token('OPERATOR', op, line, column));
        index += op.length;
        column += op.length;
        operatorMatched = true;
        break;
      }
    }
    if (operatorMatched) {
      continue;
    }

    // Handle Punctuation
    if ([';', ',', '(', ')', '{', '}', '[', ']'].includes(char)) {
      tokens.push(new Token('PUNCTUATION', char, line, column));
      index++;
      column++;
      continue;
    }

    // Fallback for unknown characters (e.g. invalid symbols)
    tokens.push(new Token('UNKNOWN', char, line, column));
    index++;
    column++;
  }

  return tokens;
}

module.exports = { tokenize, Token };
