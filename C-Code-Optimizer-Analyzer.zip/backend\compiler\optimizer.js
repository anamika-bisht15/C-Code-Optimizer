/**
 * Optimizer Engine for C-Code Optimizer and Analyzer
 * Implements 8 optimization passes on the AST:
 * 1. Constant Folding
 * 2. Constant Propagation
 * 3. Dead Code Elimination
 * 4. Common Subexpression Elimination (CSE)
 * 5. Copy Propagation
 * 6. Loop Optimization (Loop Invariant Code Motion)
 * 7. Strength Reduction
 * 8. Unused Variable Removal
 *
 * Includes a C Code Generator to produce optimized C code.
 */

/**
 * Code Generator: Converts AST back into C Code string.
 */
function generateCode(node, indentLevel = 0) {
  if (!node) return '';
  const indent = '    '.repeat(indentLevel);

  switch (node.type) {
    case 'Program':
      return node.body.map(stmt => generateCode(stmt, indentLevel)).join('\n\n');

    case 'FunctionDeclaration': {
      const params = node.params.map(p => `${p.type} ${p.name}`).join(', ');
      const bodyCode = generateCode(node.body, indentLevel);
      return `${indent}${node.returnType} ${node.name}(${params}) ${bodyCode.trim()}`;
    }

    case 'Block': {
      const stmtInd = indentLevel + 1;
      const stmts = node.statements.map(stmt => generateCode(stmt, stmtInd)).join('\n');
      return `{\n${stmts}\n${indent}}`;
    }

    case 'VariableDeclaration': {
      const initCode = node.init ? ` = ${generateCode(node.init)}` : '';
      return `${indent}${node.dataType} ${node.name}${initCode};`;
    }

    case 'Assignment': {
      return `${node.name} = ${generateCode(node.value)}`;
    }

    case 'ExpressionStatement': {
      return `${indent}${generateCode(node.expression)};`;
    }

    case 'BinaryExpression': {
      // Add parentheses to ensure correct precedence in generated code
      return `(${generateCode(node.left)} ${node.operator} ${generateCode(node.right)})`;
    }

    case 'UnaryExpression': {
      if (node.prefix) {
        return `${node.operator}${generateCode(node.argument)}`;
      } else {
        return `${generateCode(node.argument)}${node.operator}`;
      }
    }

    case 'IfStatement': {
      const cond = generateCode(node.condition);
      const thenBr = generateCode(node.thenBranch, indentLevel).trim();
      let code = `${indent}if (${cond}) `;
      
      if (node.thenBranch.type === 'Block') {
        code += `${thenBr}`;
      } else {
        code += `\n${indent}    ${thenBr}`;
      }

      if (node.elseBranch) {
        const elseBr = generateCode(node.elseBranch, indentLevel).trim();
        if (node.elseBranch.type === 'Block') {
          code += ` else ${elseBr}`;
        } else if (node.elseBranch.type === 'IfStatement') {
          code += ` else ${elseBr.trim()}`;
        } else {
          code += ` else\n${indent}    ${elseBr}`;
        }
      }
      return code;
    }

    case 'WhileStatement': {
      const cond = generateCode(node.condition);
      const body = generateCode(node.body, indentLevel).trim();
      if (node.body.type === 'Block') {
        return `${indent}while (${cond}) ${body}`;
      }
      return `${indent}while (${cond})\n${indent}    ${body}`;
    }

    case 'ForStatement': {
      let initCode = '';
      if (node.init) {
        if (node.init.type === 'VariableDeclaration') {
          initCode = generateCode(node.init).trim().replace(';', '');
        } else {
          initCode = generateCode(node.init).trim().replace(';', '');
        }
      }
      const condCode = node.condition ? generateCode(node.condition) : '';
      const updCode = node.update ? generateCode(node.update).replace(';', '') : '';
      const body = generateCode(node.body, indentLevel).trim();
      
      const header = `for (${initCode}; ${condCode}; ${updCode})`;
      if (node.body.type === 'Block') {
        return `${indent}${header} ${body}`;
      }
      return `${indent}${header}\n${indent}    ${body}`;
    }

    case 'ReturnStatement': {
      const val = node.value ? ` ${generateCode(node.value)}` : '';
      return `${indent}return${val};`;
    }

    case 'BreakStatement':
      return `${indent}break;`;

    case 'ContinueStatement':
      return `${indent}continue;`;

    case 'Identifier':
      return node.name;

    case 'Literal':
      return node.raw || String(node.value);

    case 'FunctionCall': {
      const args = node.arguments.map(arg => generateCode(arg)).join(', ');
      return `${node.name}(${args})`;
    }

    default:
      return '';
  }
}

/**
 * Deep clones an AST node to avoid side-effects during optimization passes.
 */
function cloneAST(node) {
  return JSON.parse(JSON.stringify(node));
}

/**
 * 1. Constant Folding
 * Evaluates binary expressions of literal numbers.
 */
function constantFolding(node) {
  if (!node) return null;

  // Process children first
  if (node.type === 'Program') {
    node.body = node.body.map(constantFolding);
  } else if (node.type === 'FunctionDeclaration') {
    node.body = constantFolding(node.body);
  } else if (node.type === 'Block') {
    node.statements = node.statements.map(constantFolding);
  } else if (node.type === 'VariableDeclaration' && node.init) {
    node.init = constantFolding(node.init);
  } else if (node.type === 'Assignment') {
    node.value = constantFolding(node.value);
  } else if (node.type === 'ExpressionStatement') {
    node.expression = constantFolding(node.expression);
  } else if (node.type === 'IfStatement') {
    node.condition = constantFolding(node.condition);
    node.thenBranch = constantFolding(node.thenBranch);
    if (node.elseBranch) node.elseBranch = constantFolding(node.elseBranch);
  } else if (node.type === 'WhileStatement') {
    node.condition = constantFolding(node.condition);
    node.body = constantFolding(node.body);
  } else if (node.type === 'ForStatement') {
    if (node.init) node.init = constantFolding(node.init);
    if (node.condition) node.condition = constantFolding(node.condition);
    if (node.update) node.update = constantFolding(node.update);
    node.body = constantFolding(node.body);
  } else if (node.type === 'ReturnStatement' && node.value) {
    node.value = constantFolding(node.value);
  } else if (node.type === 'FunctionCall') {
    node.arguments = node.arguments.map(constantFolding);
  } else if (node.type === 'UnaryExpression') {
    node.argument = constantFolding(node.argument);
    // Fold unary operations on literal numbers
    if (node.argument.type === 'Literal' && typeof node.argument.value === 'number') {
      const val = node.argument.value;
      if (node.operator === '-') {
        return { type: 'Literal', value: -val, raw: String(-val) };
      } else if (node.operator === '!') {
        return { type: 'Literal', value: val ? 0 : 1, raw: val ? '0' : '1' };
      } else if (node.operator === '~') {
        return { type: 'Literal', value: ~val, raw: String(~val) };
      }
    }
  } else if (node.type === 'BinaryExpression') {
    node.left = constantFolding(node.left);
    node.right = constantFolding(node.right);

    if (node.left.type === 'Literal' && node.right.type === 'Literal') {
      const leftVal = node.left.value;
      const rightVal = node.right.value;

      if (typeof leftVal === 'number' && typeof rightVal === 'number') {
        let result;
        switch (node.operator) {
          case '+': result = leftVal + rightVal; break;
          case '-': result = leftVal - rightVal; break;
          case '*': result = leftVal * rightVal; break;
          case '/': result = rightVal !== 0 ? Math.floor(leftVal / rightVal) : 0; break;
          case '%': result = rightVal !== 0 ? leftVal % rightVal : 0; break;
          case '<<': result = leftVal << rightVal; break;
          case '>>': result = leftVal >> rightVal; break;
          case '==': result = leftVal === rightVal ? 1 : 0; break;
          case '!=': result = leftVal !== rightVal ? 1 : 0; break;
          case '<': result = leftVal < rightVal ? 1 : 0; break;
          case '<=': result = leftVal <= rightVal ? 1 : 0; break;
          case '>': result = leftVal > rightVal ? 1 : 0; break;
          case '>=': result = leftVal >= rightVal ? 1 : 0; break;
          case '&&': result = (leftVal && rightVal) ? 1 : 0; break;
          case '||': result = (leftVal || rightVal) ? 1 : 0; break;
          default: return node;
        }
        return { type: 'Literal', value: result, raw: String(result) };
      }
    }
  }

  return node;
}

/**
 * 2. Constant & 5. Copy Propagation
 * Propagates values from definitions to uses.
 * Within a basic block (like a Block node), tracks which variables are constants or copies.
 */
function propagateValues(node, context = { constants: {}, copies: {} }) {
  if (!node) return null;

  switch (node.type) {
    case 'Program':
      node.body = node.body.map(stmt => propagateValues(stmt, context));
      break;

    case 'FunctionDeclaration':
      // Reset context for function boundary
      node.body = propagateValues(node.body, { constants: {}, copies: {} });
      break;

    case 'Block':
      // Sequence of statements: propagate in order, updating context
      node.statements = node.statements.map(stmt => propagateValues(stmt, context));
      break;

    case 'VariableDeclaration':
      if (node.init) {
        // Propagate first on the initializer
        node.init = propagateValues(node.init, context);

        if (node.init.type === 'Literal') {
          context.constants[node.name] = node.init;
          delete context.copies[node.name];
        } else if (node.init.type === 'Identifier') {
          context.copies[node.name] = node.init.name;
          delete context.constants[node.name];
        } else {
          // If initialized to expression, it breaks previous constant/copy values
          delete context.constants[node.name];
          delete context.copies[node.name];
        }
      }
      break;

    case 'Assignment':
      // Propagate on RHS
      node.value = propagateValues(node.value, context);

      if (node.value.type === 'Literal') {
        context.constants[node.name] = node.value;
        delete context.copies[node.name];
      } else if (node.value.type === 'Identifier') {
        context.copies[node.name] = node.value.name;
        delete context.constants[node.name];
      } else {
        delete context.constants[node.name];
        delete context.copies[node.name];
      }

      // If this variable is copied to other variables, they are no longer copies of it if it gets modified!
      for (const [key, val] of Object.entries(context.copies)) {
        if (val === node.name || key === node.name) {
          delete context.copies[key];
        }
      }
      break;

    case 'ExpressionStatement':
      node.expression = propagateValues(node.expression, context);
      break;

    case 'BinaryExpression':
      node.left = propagateValues(node.left, context);
      node.right = propagateValues(node.right, context);
      break;

    case 'UnaryExpression':
      node.argument = propagateValues(node.argument, context);
      // If we reassign or increment/decrement, we invalidate the constant/copy
      if (node.operator === '++' || node.operator === '--') {
        if (node.argument.type === 'Identifier') {
          const varName = node.argument.name;
          delete context.constants[varName];
          delete context.copies[varName];
          for (const [key, val] of Object.entries(context.copies)) {
            if (val === varName || key === varName) delete context.copies[key];
          }
        }
      }
      break;

    case 'Identifier':
      // CONSTANT PROPAGATION: replace identifier with literal
      if (context.constants[node.name]) {
        return cloneAST(context.constants[node.name]);
      }
      // COPY PROPAGATION: replace identifier with copied identifier
      if (context.copies[node.name]) {
        return { type: 'Identifier', name: context.copies[node.name] };
      }
      break;

    case 'IfStatement':
      node.condition = propagateValues(node.condition, context);
      // We process branches with copies of the context to avoid leaks across alternative flows
      node.thenBranch = propagateValues(node.thenBranch, {
        constants: { ...context.constants },
        copies: { ...context.copies }
      });
      if (node.elseBranch) {
        node.elseBranch = propagateValues(node.elseBranch, {
          constants: { ...context.constants },
          copies: { ...context.copies }
        });
      }
      break;

    case 'WhileStatement': {
      // Clear all constants/copies that might be modified in loop body
      const writtenVars = getWrittenVariables(node.body);
      writtenVars.forEach(v => {
        delete context.constants[v];
        delete context.copies[v];
      });
      node.condition = propagateValues(node.condition, context);
      node.body = propagateValues(node.body, {
        constants: { ...context.constants },
        copies: { ...context.copies }
      });
      break;
    }

    case 'ForStatement': {
      if (node.init) node.init = propagateValues(node.init, context);
      const forWritten = getWrittenVariables(node.body);
      forWritten.forEach(v => {
        delete context.constants[v];
        delete context.copies[v];
      });
      if (node.condition) node.condition = propagateValues(node.condition, context);
      if (node.update) node.update = propagateValues(node.update, context);
      node.body = propagateValues(node.body, {
        constants: { ...context.constants },
        copies: { ...context.copies }
      });
      break;
    }

    case 'ReturnStatement':
      if (node.value) node.value = propagateValues(node.value, context);
      break;

    case 'FunctionCall':
      node.arguments = node.arguments.map(arg => propagateValues(arg, context));
      break;
  }

  return node;
}

/**
 * Helper: extracts names of variables that are assigned or incremented in a node
 */
function getWrittenVariables(node) {
  const vars = new Set();
  const walk = (n) => {
    if (!n) return;
    if (n.type === 'Assignment') {
      vars.add(n.name);
    } else if (n.type === 'VariableDeclaration') {
      vars.add(n.name);
    } else if (n.type === 'UnaryExpression' && (n.operator === '++' || n.operator === '--')) {
      if (n.argument.type === 'Identifier') vars.add(n.argument.name);
    }
    // recurse
    for (const key in n) {
      if (n[key] && typeof n[key] === 'object') {
        if (Array.isArray(n[key])) {
          n[key].forEach(walk);
        } else {
          walk(n[key]);
        }
      }
    }
  };
  walk(node);
  return vars;
}

/**
 * 3. Dead Code Elimination
 * Removes dead code blocks (like if(0) or statements after return).
 */
function deadCodeElimination(node) {
  if (!node) return null;

  if (node.type === 'Program') {
    node.body = node.body.map(deadCodeElimination).filter(Boolean);
  } else if (node.type === 'FunctionDeclaration') {
    node.body = deadCodeElimination(node.body);
  } else if (node.type === 'Block') {
    // 1. Process statements in block
    let newStmts = [];
    let unreachable = false;
    for (let stmt of node.statements) {
      if (unreachable) {
        // Drop any statements after return/break/continue
        continue;
      }
      const processed = deadCodeElimination(stmt);
      if (processed) {
        newStmts.push(processed);
        if (processed.type === 'ReturnStatement' || processed.type === 'BreakStatement' || processed.type === 'ContinueStatement') {
          unreachable = true;
        }
      }
    }
    node.statements = newStmts;
  } else if (node.type === 'IfStatement') {
    node.condition = deadCodeElimination(node.condition);
    node.thenBranch = deadCodeElimination(node.thenBranch);
    if (node.elseBranch) node.elseBranch = deadCodeElimination(node.elseBranch);

    // If condition is constant
    if (node.condition.type === 'Literal') {
      const val = node.condition.value;
      if (val !== 0) {
        // Condition is truthy, replace IfStmt with thenBranch
        return node.thenBranch;
      } else {
        // Condition is falsy, replace IfStmt with elseBranch or null
        return node.elseBranch || null;
      }
    }
  } else if (node.type === 'WhileStatement') {
    node.condition = deadCodeElimination(node.condition);
    node.body = deadCodeElimination(node.body);

    if (node.condition.type === 'Literal' && node.condition.value === 0) {
      // while(0) is dead code
      return null;
    }
  } else if (node.type === 'ForStatement') {
    if (node.init) node.init = deadCodeElimination(node.init);
    if (node.condition) node.condition = deadCodeElimination(node.condition);
    if (node.update) node.update = deadCodeElimination(node.update);
    node.body = deadCodeElimination(node.body);

    if (node.condition && node.condition.type === 'Literal' && node.condition.value === 0) {
      // for(; 0; ) is dead code
      return node.init ? { type: 'ExpressionStatement', expression: node.init } : null;
    }
  } else if (node.type === 'ExpressionStatement') {
    node.expression = deadCodeElimination(node.expression);
  } else if (node.type === 'VariableDeclaration' && node.init) {
    node.init = deadCodeElimination(node.init);
  } else if (node.type === 'Assignment') {
    node.value = deadCodeElimination(node.value);
  } else if (node.type === 'BinaryExpression') {
    node.left = deadCodeElimination(node.left);
    node.right = deadCodeElimination(node.right);
  }

  return node;
}

/**
 * 4. Common Subexpression Elimination (CSE)
 * Detects repeated computations inside a block and replaces them.
 * e.g.,
 *   a = x + y;
 *   b = x + y;
 * becomes:
 *   a = x + y;
 *   b = a;
 */
function commonSubexpressionElimination(node) {
  if (!node) return null;

  if (node.type === 'Program') {
    node.body = node.body.map(commonSubexpressionElimination);
  } else if (node.type === 'FunctionDeclaration') {
    node.body = commonSubexpressionElimination(node.body);
  } else if (node.type === 'Block') {
    const expressionsMap = {}; // stringified expr -> varName
    const newStatements = [];

    for (let stmt of node.statements) {
      if (stmt.type === 'VariableDeclaration' && stmt.init) {
        stmt.init = replaceExpressions(stmt.init, expressionsMap);
        
        // Register the expression in map
        const exprStr = stringifyExpr(stmt.init);
        if (exprStr && !expressionsMap[exprStr]) {
          expressionsMap[exprStr] = stmt.name;
        }

        // If declaration target itself gets re-assigned, clear expressions containing it
        invalidateExprsWithVar(stmt.name, expressionsMap);
        newStatements.push(stmt);
      } 
      else if (stmt.type === 'ExpressionStatement' && stmt.expression.type === 'Assignment') {
        const assign = stmt.expression;
        assign.value = replaceExpressions(assign.value, expressionsMap);

        const exprStr = stringifyExpr(assign.value);
        if (exprStr && !expressionsMap[exprStr]) {
          expressionsMap[exprStr] = assign.name;
        }

        invalidateExprsWithVar(assign.name, expressionsMap);
        newStatements.push(stmt);
      } 
      else {
        // Standard statement recursion
        newStatements.push(commonSubexpressionElimination(stmt));
      }
    }
    node.statements = newStatements;
  } else if (node.type === 'IfStatement') {
    node.thenBranch = commonSubexpressionElimination(node.thenBranch);
    if (node.elseBranch) node.elseBranch = commonSubexpressionElimination(node.elseBranch);
  } else if (node.type === 'WhileStatement') {
    node.body = commonSubexpressionElimination(node.body);
  } else if (node.type === 'ForStatement') {
    node.body = commonSubexpressionElimination(node.body);
  }

  return node;
}

function stringifyExpr(node) {
  if (!node) return '';
  if (node.type === 'BinaryExpression') {
    return `${stringifyExpr(node.left)} ${node.operator} ${stringifyExpr(node.right)}`;
  }
  if (node.type === 'Identifier') {
    return node.name;
  }
  if (node.type === 'Literal') {
    return String(node.value);
  }
  return '';
}

function replaceExpressions(node, expressionsMap) {
  if (!node) return null;

  const str = stringifyExpr(node);
  if (str && expressionsMap[str]) {
    // Replace expression with the variable that holds its result
    return { type: 'Identifier', name: expressionsMap[str] };
  }

  if (node.type === 'BinaryExpression') {
    node.left = replaceExpressions(node.left, expressionsMap);
    node.right = replaceExpressions(node.right, expressionsMap);
  }

  return node;
}

function invalidateExprsWithVar(varName, expressionsMap) {
  for (const exprStr of Object.keys(expressionsMap)) {
    // If the expression uses this variable, invalidate it
    if (exprStr.split(' ').includes(varName)) {
      delete expressionsMap[exprStr];
    }
  }
}

/**
 * 6. Loop Optimization (Loop Invariant Code Motion)
 * Identifies statements in loops whose inputs do not change inside the loop body,
 * and lifts them outside the loop.
 */
function loopOptimization(node) {
  if (!node) return null;

  // Process children
  if (node.type === 'Program') {
    node.body = node.body.map(loopOptimization);
  } else if (node.type === 'FunctionDeclaration') {
    node.body = loopOptimization(node.body);
  } else if (node.type === 'Block') {
    // In block, if we find a loop, we can hoist invariants before it!
    const newStatements = [];
    for (let stmt of node.statements) {
      if (stmt.type === 'WhileStatement' || stmt.type === 'ForStatement') {
        const optimizedLoop = loopOptimization(stmt);
        
        // Analyze loop body for invariants
        const bodyStmts = getBlockStatements(optimizedLoop.body);
        const writtenVars = getWrittenVariables(optimizedLoop.body);
        
        // Check for invariant assignments
        const invariants = [];
        const remainingStmts = [];

        for (let bodyStmt of bodyStmts) {
          if (bodyStmt.type === 'VariableDeclaration' && bodyStmt.init) {
            const used = getUsedVariables(bodyStmt.init);
            const isInvariant = [...used].every(v => !writtenVars.has(v));
            if (isInvariant) {
              invariants.push(bodyStmt);
            } else {
              remainingStmts.push(bodyStmt);
            }
          } else if (bodyStmt.type === 'ExpressionStatement' && bodyStmt.expression.type === 'Assignment') {
            const assign = bodyStmt.expression;
            const used = getUsedVariables(assign.value);
            const isInvariant = [...used].every(v => !writtenVars.has(v)) && !writtenVars.has(assign.name); // variable itself not modified multiple times/other places
            if (isInvariant) {
              // Hoist it as expression statement or var declaration
              invariants.push(bodyStmt);
            } else {
              remainingStmts.push(bodyStmt);
            }
          } else {
            remainingStmts.push(bodyStmt);
          }
        }

        // Add hoisted invariants before loop
        newStatements.push(...invariants);

        // Update loop body
        if (optimizedLoop.body.type === 'Block') {
          optimizedLoop.body.statements = remainingStmts;
        } else {
          // If body was a single statement and it got hoisted, replace loop body with empty block or next
          optimizedLoop.body = { type: 'Block', statements: remainingStmts };
        }

        newStatements.push(optimizedLoop);
      } else {
        newStatements.push(loopOptimization(stmt));
      }
    }
    node.statements = newStatements;
  } else if (node.type === 'IfStatement') {
    node.thenBranch = loopOptimization(node.thenBranch);
    if (node.elseBranch) node.elseBranch = loopOptimization(node.elseBranch);
  } else if (node.type === 'WhileStatement') {
    node.body = loopOptimization(node.body);
  } else if (node.type === 'ForStatement') {
    node.body = loopOptimization(node.body);
  }

  return node;
}

function getBlockStatements(node) {
  if (!node) return [];
  if (node.type === 'Block') return node.statements;
  return [node];
}

function getUsedVariables(node) {
  const vars = new Set();
  const walk = (n) => {
    if (!n) return;
    if (n.type === 'Identifier') {
      vars.add(n.name);
    }
    for (const key in n) {
      if (n[key] && typeof n[key] === 'object') {
        if (Array.isArray(n[key])) n[key].forEach(walk);
        else walk(n[key]);
      }
    }
  };
  walk(node);
  return vars;
}

/**
 * 7. Strength Reduction
 * Replaces expensive operators (multiplication, division) with shifts/adds.
 * e.g.,
 *   x * 2 -> x << 1
 *   x * 0 -> 0
 *   x * 1 -> x
 */
function strengthReduction(node) {
  if (!node) return null;

  // Recurse children
  if (node.type === 'Program') {
    node.body = node.body.map(strengthReduction);
  } else if (node.type === 'FunctionDeclaration') {
    node.body = strengthReduction(node.body);
  } else if (node.type === 'Block') {
    node.statements = node.statements.map(strengthReduction);
  } else if (node.type === 'VariableDeclaration' && node.init) {
    node.init = strengthReduction(node.init);
  } else if (node.type === 'Assignment') {
    node.value = strengthReduction(node.value);
  } else if (node.type === 'ExpressionStatement') {
    node.expression = strengthReduction(node.expression);
  } else if (node.type === 'IfStatement') {
    node.condition = strengthReduction(node.condition);
    node.thenBranch = strengthReduction(node.thenBranch);
    if (node.elseBranch) node.elseBranch = strengthReduction(node.elseBranch);
  } else if (node.type === 'WhileStatement') {
    node.condition = strengthReduction(node.condition);
    node.body = strengthReduction(node.body);
  } else if (node.type === 'ForStatement') {
    if (node.init) node.init = strengthReduction(node.init);
    if (node.condition) node.condition = strengthReduction(node.condition);
    if (node.update) node.update = strengthReduction(node.update);
    node.body = strengthReduction(node.body);
  } else if (node.type === 'ReturnStatement' && node.value) {
    node.value = strengthReduction(node.value);
  } else if (node.type === 'UnaryExpression') {
    node.argument = strengthReduction(node.argument);
  } else if (node.type === 'BinaryExpression') {
    node.left = strengthReduction(node.left);
    node.right = strengthReduction(node.right);

    // Check multiplication/division by powers of 2
    if (node.operator === '*') {
      if (node.right.type === 'Literal' && typeof node.right.value === 'number') {
        const val = node.right.value;
        if (val === 0) return { type: 'Literal', value: 0, raw: '0' };
        if (val === 1) return node.left;
        if (isPowerOfTwo(val)) {
          const power = Math.log2(val);
          return {
            type: 'BinaryExpression',
            operator: '<<',
            left: node.left,
            right: { type: 'Literal', value: power, raw: String(power) }
          };
        }
      }
      if (node.left.type === 'Literal' && typeof node.left.value === 'number') {
        const val = node.left.value;
        if (val === 0) return { type: 'Literal', value: 0, raw: '0' };
        if (val === 1) return node.right;
        if (isPowerOfTwo(val)) {
          const power = Math.log2(val);
          return {
            type: 'BinaryExpression',
            operator: '<<',
            left: node.right,
            right: { type: 'Literal', value: power, raw: String(power) }
          };
        }
      }
    } else if (node.operator === '/') {
      if (node.right.type === 'Literal' && typeof node.right.value === 'number') {
        const val = node.right.value;
        if (val === 1) return node.left;
        if (isPowerOfTwo(val)) {
          const power = Math.log2(val);
          return {
            type: 'BinaryExpression',
            operator: '>>',
            left: node.left,
            right: { type: 'Literal', value: power, raw: String(power) }
          };
        }
      }
    }
  }

  return node;
}

function isPowerOfTwo(x) {
  return x > 0 && (x & (x - 1)) === 0;
}

/**
 * 8. Unused Variable Removal
 * Declared variables that are never read/referenced in calculations are removed.
 */
function removeUnusedVariables(node) {
  if (!node) return null;

  // Let's count uses first
  const useCounts = {};
  const trackUses = (n) => {
    if (!n) return;
    if (n.type === 'Identifier') {
      useCounts[n.name] = (useCounts[n.name] || 0) + 1;
    }
    // We shouldn't count occurrences on the LHS of assignments or declarations as "reads",
    // but standard reads are in expressions. Let's do simple AST walk and discount declarations and LHS assignments.
    for (const key in n) {
      if (n[key] && typeof n[key] === 'object') {
        if (Array.isArray(n[key])) n[key].forEach(trackUses);
        else trackUses(n[key]);
      }
    }
  };

  // Run the walker on the entire tree to register uses
  trackUses(node);

  // Now filter the AST
  const filterAST = (n) => {
    if (!n) return null;

    if (n.type === 'Program') {
      n.body = n.body.map(filterAST).filter(Boolean);
    } else if (n.type === 'FunctionDeclaration') {
      // Don't remove function parameters, only function body variables
      n.body = filterAST(n.body);
    } else if (n.type === 'Block') {
      n.statements = n.statements.map(filterAST).filter(Boolean);
    } else if (n.type === 'VariableDeclaration') {
      // If it is never used (read), remove it
      if (!useCounts[n.name] || useCounts[n.name] === 0) {
        return null;
      }
      if (n.init) n.init = filterAST(n.init);
    } else if (n.type === 'ExpressionStatement' && n.expression.type === 'Assignment') {
      const assign = n.expression;
      if (!useCounts[assign.name] || useCounts[assign.name] === 0) {
        return null; // assignment to unused variable is dead
      }
      assign.value = filterAST(assign.value);
    } else {
      // Generic recursion
      for (const key in n) {
        if (n[key] && typeof n[key] === 'object') {
          if (Array.isArray(n[key])) {
            n[key] = n[key].map(filterAST).filter(Boolean);
          } else {
            n[key] = filterAST(n[key]);
          }
        }
      }
    }
    return n;
  };

  return filterAST(node);
}

/**
 * Main function: Runs all optimizations on the AST sequentially.
 */
function optimizeAST(ast) {
  let optimized = cloneAST(ast);

  // We run multiple optimization passes in a logical sequence:
  // 1. Constant Propagation & Copy Propagation
  optimized = propagateValues(optimized);
  // 2. Constant Folding
  optimized = constantFolding(optimized);
  // 3. Dead Code Elimination
  optimized = deadCodeElimination(optimized);
  // 4. Strength Reduction
  optimized = strengthReduction(optimized);
  // 5. Common Subexpression Elimination
  optimized = commonSubexpressionElimination(optimized);
  // 6. Loop Optimization
  optimized = loopOptimization(optimized);
  // 7. Final Cleanups: propagate again to clean up any folded loops/conditions
  optimized = propagateValues(optimized);
  optimized = constantFolding(optimized);
  optimized = deadCodeElimination(optimized);
  // 8. Unused Variable Removal
  optimized = removeUnusedVariables(optimized);

  return optimized;
}

module.exports = {
  optimizeAST,
  generateCode,
  constantFolding,
  propagateValues,
  deadCodeElimination,
  commonSubexpressionElimination,
  loopOptimization,
  strengthReduction,
  removeUnusedVariables
};
