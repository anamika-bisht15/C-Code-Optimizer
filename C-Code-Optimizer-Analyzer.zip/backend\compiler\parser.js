/**
 * Parser for C-Code Optimizer and Analyzer
 * Parses the token stream from the Lexer and constructs an AST and a Parse Tree.
 */

class Parser {
  constructor(tokens) {
    // Filter out comments for syntactic analysis, but keep track of them
    this.allTokens = tokens;
    this.tokens = tokens.filter(t => t.type !== 'COMMENT');
    this.current = 0;
    this.errors = [];
  }

  peek() {
    if (this.isAtEnd()) return null;
    return this.tokens[this.current];
  }

  previous() {
    return this.tokens[this.current - 1];
  }

  isAtEnd() {
    return this.current >= this.tokens.length;
  }

  advance() {
    if (!this.isAtEnd()) this.current++;
    return this.previous();
  }

  check(type, value = null) {
    if (this.isAtEnd()) return false;
    const token = this.peek();
    if (token.type !== type) return false;
    if (value !== null && token.value !== value) return false;
    return true;
  }

  match(type, value = null) {
    if (this.check(type, value)) {
      this.advance();
      return true;
    }
    return false;
  }

  consume(type, message, value = null) {
    if (this.check(type, value)) {
      return this.advance();
    }
    const token = this.peek();
    const line = token ? token.line : (this.tokens[this.tokens.length - 1]?.line || 1);
    const col = token ? token.column : (this.tokens[this.tokens.length - 1]?.column || 1);
    const error = new Error(`Line ${line}, Col ${col}: ${message} (Got '${token ? token.value : 'EOF'}')`);
    error.line = line;
    error.column = col;
    this.errors.push(error.message);
    throw error;
  }

  parse() {
    const ast = {
      type: 'Program',
      body: [],
      tokens: this.allTokens // include all tokens (including comments)
    };

    while (!this.isAtEnd()) {
      try {
        ast.body.push(this.declaration());
      } catch (e) {
        this.synchronize();
      }
    }

    return {
      ast,
      errors: this.errors,
      parseTree: this.buildParseTree(ast)
    };
  }

  synchronize() {
    this.advance();
    while (!this.isAtEnd()) {
      if (this.previous().value === ';') return;

      switch (this.peek().value) {
        case 'int':
        case 'float':
        case 'double':
        case 'char':
        case 'void':
        case 'if':
        case 'while':
        case 'for':
        case 'return':
          return;
      }
      this.advance();
    }
  }

  declaration() {
    // Check if it's a function or variable declaration
    const isType = this.check('KEYWORD', 'int') || 
                   this.check('KEYWORD', 'float') || 
                   this.check('KEYWORD', 'double') || 
                   this.check('KEYWORD', 'char') || 
                   this.check('KEYWORD', 'void');

    if (isType) {
      const typeToken = this.advance();
      const nameToken = this.consume('IDENTIFIER', 'Expect identifier after type');

      // If open parenthesis, it's a function declaration
      if (this.match('PUNCTUATION', '(')) {
        return this.functionDeclaration(typeToken.value, nameToken.value);
      }

      // Otherwise, it's a variable declaration
      return this.variableDeclaration(typeToken.value, nameToken.value);
    }

    return this.statement();
  }

  functionDeclaration(returnType, name) {
    const params = [];
    if (!this.check('PUNCTUATION', ')')) {
      do {
        const paramType = this.consume('KEYWORD', 'Expect parameter type');
        const paramName = this.consume('IDENTIFIER', 'Expect parameter name');
        params.push({ type: paramType.value, name: paramName.value });
      } while (this.match('PUNCTUATION', ','));
    }
    this.consume('PUNCTUATION', "Expect ')' after parameters", ')');

    this.consume('PUNCTUATION', "Expect '{' before function body", '{');
    const body = this.block();

    return {
      type: 'FunctionDeclaration',
      returnType,
      name,
      params,
      body
    };
  }

  variableDeclaration(dataType, name) {
    let init = null;
    if (this.match('OPERATOR', '=')) {
      init = this.expression();
    }
    this.consume('PUNCTUATION', "Expect ';' after variable declaration", ';');

    return {
      type: 'VariableDeclaration',
      dataType,
      name,
      init
    };
  }

  statement() {
    if (this.match('PUNCTUATION', '{')) {
      return this.block();
    }
    if (this.match('KEYWORD', 'if')) {
      return this.ifStatement();
    }
    if (this.match('KEYWORD', 'while')) {
      return this.whileStatement();
    }
    if (this.match('KEYWORD', 'for')) {
      return this.forStatement();
    }
    if (this.match('KEYWORD', 'return')) {
      return this.returnStatement();
    }
    if (this.match('KEYWORD', 'break')) {
      this.consume('PUNCTUATION', "Expect ';'", ';');
      return { type: 'BreakStatement' };
    }
    if (this.match('KEYWORD', 'continue')) {
      this.consume('PUNCTUATION', "Expect ';'", ';');
      return { type: 'ContinueStatement' };
    }

    return this.expressionStatement();
  }

  block() {
    const statements = [];
    while (!this.check('PUNCTUATION', '}') && !this.isAtEnd()) {
      statements.push(this.declaration());
    }
    this.consume('PUNCTUATION', "Expect '}' after block", '}');
    return {
      type: 'Block',
      statements
    };
  }

  ifStatement() {
    this.consume('PUNCTUATION', "Expect '(' after 'if'", '(');
    const condition = this.expression();
    this.consume('PUNCTUATION', "Expect ')' after if condition", ')');

    const thenBranch = this.statement();
    let elseBranch = null;
    if (this.match('KEYWORD', 'else')) {
      elseBranch = this.statement();
    }

    return {
      type: 'IfStatement',
      condition,
      thenBranch,
      elseBranch
    };
  }

  whileStatement() {
    this.consume('PUNCTUATION', "Expect '(' after 'while'", '(');
    const condition = this.expression();
    this.consume('PUNCTUATION', "Expect ')' after while condition", ')');
    const body = this.statement();

    return {
      type: 'WhileStatement',
      condition,
      body
    };
  }

  forStatement() {
    this.consume('PUNCTUATION', "Expect '(' after 'for'", '(');
    
    let init = null;
    if (!this.check('PUNCTUATION', ';')) {
      if (this.check('KEYWORD', 'int') || this.check('KEYWORD', 'float') || this.check('KEYWORD', 'double')) {
        const typeToken = this.advance();
        const nameToken = this.consume('IDENTIFIER', 'Expect variable name');
        init = this.variableDeclaration(typeToken.value, nameToken.value);
      } else {
        init = this.expressionStatement();
      }
    } else {
      this.consume('PUNCTUATION', "Expect ';'", ';');
    }

    let condition = null;
    if (!this.check('PUNCTUATION', ';')) {
      condition = this.expression();
    }
    this.consume('PUNCTUATION', "Expect ';'", ';');

    let update = null;
    if (!this.check('PUNCTUATION', ')')) {
      update = this.expression();
    }
    this.consume('PUNCTUATION', "Expect ')'", ')');

    const body = this.statement();

    return {
      type: 'ForStatement',
      init,
      condition,
      update,
      body
    };
  }

  returnStatement() {
    let value = null;
    if (!this.check('PUNCTUATION', ';')) {
      value = this.expression();
    }
    this.consume('PUNCTUATION', "Expect ';' after return statement", ';');
    return {
      type: 'ReturnStatement',
      value
    };
  }

  expressionStatement() {
    const expr = this.expression();
    this.consume('PUNCTUATION', "Expect ';' after expression", ';');
    return {
      type: 'ExpressionStatement',
      expression: expr
    };
  }

  expression() {
    return this.assignment();
  }

  assignment() {
    const expr = this.logicalOr();

    if (this.match('OPERATOR', '=')) {
      const equals = this.previous();
      const value = this.assignment();

      if (expr.type === 'Identifier') {
        return {
          type: 'Assignment',
          name: expr.name,
          value
        };
      }
      
      throw new Error(`Line ${equals.line}: Invalid assignment target`);
    }

    return expr;
  }

  logicalOr() {
    let expr = this.logicalAnd();
    while (this.match('OPERATOR', '||')) {
      const operator = this.previous().value;
      const right = this.logicalAnd();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  logicalAnd() {
    let expr = this.equality();
    while (this.match('OPERATOR', '&&')) {
      const operator = this.previous().value;
      const right = this.equality();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  equality() {
    let expr = this.comparison();
    while (this.match('OPERATOR', '==') || this.match('OPERATOR', '!=')) {
      const operator = this.previous().value;
      const right = this.comparison();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  comparison() {
    let expr = this.shift();
    while (
      this.match('OPERATOR', '<') || this.match('OPERATOR', '<=') ||
      this.match('OPERATOR', '>') || this.match('OPERATOR', '>=')
    ) {
      const operator = this.previous().value;
      const right = this.shift();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  shift() {
    let expr = this.term();
    while (this.match('OPERATOR', '<<') || this.match('OPERATOR', '>>')) {
      const operator = this.previous().value;
      const right = this.term();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  term() {
    let expr = this.factor();
    while (this.match('OPERATOR', '+') || this.match('OPERATOR', '-')) {
      const operator = this.previous().value;
      const right = this.factor();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  factor() {
    let expr = this.unary();
    while (this.match('OPERATOR', '*') || this.match('OPERATOR', '/') || this.match('OPERATOR', '%')) {
      const operator = this.previous().value;
      const right = this.unary();
      expr = {
        type: 'BinaryExpression',
        operator,
        left: expr,
        right
      };
    }
    return expr;
  }

  unary() {
    if (this.match('OPERATOR', '!') || this.match('OPERATOR', '-') || this.match('OPERATOR', '~')) {
      const operator = this.previous().value;
      const right = this.unary();
      return {
        type: 'UnaryExpression',
        operator,
        argument: right,
        prefix: true
      };
    }

    if (this.match('OPERATOR', '++') || this.match('OPERATOR', '--')) {
      const operator = this.previous().value;
      const right = this.unary(); // e.g. ++i
      return {
        type: 'UnaryExpression',
        operator,
        argument: right,
        prefix: true
      };
    }

    // Now look for primary and optional postfix
    let expr = this.primary();

    if (this.match('OPERATOR', '++') || this.match('OPERATOR', '--')) {
      const operator = this.previous().value;
      expr = {
        type: 'UnaryExpression',
        operator,
        argument: expr,
        prefix: false
      };
    }

    return expr;
  }

  primary() {
    if (this.match('NUMBER')) {
      const val = this.previous().value;
      return {
        type: 'Literal',
        value: val.includes('.') ? parseFloat(val) : parseInt(val, 10),
        raw: val
      };
    }

    if (this.match('STRING')) {
      return {
        type: 'Literal',
        value: this.previous().value.replace(/^"|"$/g, ''),
        raw: this.previous().value
      };
    }

    if (this.match('IDENTIFIER')) {
      const name = this.previous().value;
      // Check if it's a function call
      if (this.match('PUNCTUATION', '(')) {
        const args = [];
        if (!this.check('PUNCTUATION', ')')) {
          do {
            args.push(this.expression());
          } while (this.match('PUNCTUATION', ','));
        }
        this.consume('PUNCTUATION', "Expect ')' after arguments", ')');
        return {
          type: 'FunctionCall',
          name,
          arguments: args
        };
      }
      return {
        type: 'Identifier',
        name
      };
    }

    if (this.match('PUNCTUATION', '(')) {
      const expr = this.expression();
      this.consume('PUNCTUATION', "Expect ')' after expression", ')');
      return expr;
    }

    throw new Error(`Expect expression near '${this.peek() ? this.peek().value : 'EOF'}'`);
  }

  /**
   * Helper function to build a structured Parse Tree from the AST.
   * This structure can be directly used by tree rendering libraries (e.g. React-D3-Tree).
   */
  buildParseTree(node) {
    if (!node) return null;

    const parseNode = (n) => {
      if (!n) return null;

      switch (n.type) {
        case 'Program':
          return {
            name: 'Program',
            children: n.body.map(parseNode).filter(Boolean)
          };
        case 'FunctionDeclaration':
          return {
            name: `FnDecl: ${n.returnType} ${n.name}()`,
            children: [
              {
                name: 'Params',
                children: n.params.map(p => ({ name: `${p.type} ${p.name}` }))
              },
              parseNode(n.body)
            ].filter(Boolean)
          };
        case 'Block':
          return {
            name: 'Block {}',
            children: n.statements.map(parseNode).filter(Boolean)
          };
        case 'VariableDeclaration':
          return {
            name: `VarDecl: ${n.dataType} ${n.name}`,
            children: n.init ? [parseNode(n.init)] : []
          };
        case 'Assignment':
          return {
            name: `Assign: ${n.name} =`,
            children: [parseNode(n.value)].filter(Boolean)
          };
        case 'ExpressionStatement':
          return {
            name: 'ExprStmt',
            children: [parseNode(n.expression)].filter(Boolean)
          };
        case 'BinaryExpression':
          return {
            name: `BinaryExpr: ${n.operator}`,
            children: [parseNode(n.left), parseNode(n.right)].filter(Boolean)
          };
        case 'UnaryExpression':
          return {
            name: `UnaryExpr: ${n.prefix ? 'pre-' : 'post-'}${n.operator}`,
            children: [parseNode(n.argument)].filter(Boolean)
          };
        case 'IfStatement':
          const ifChildren = [parseNode(n.condition), parseNode(n.thenBranch)];
          if (n.elseBranch) ifChildren.push(parseNode(n.elseBranch));
          return {
            name: 'IfStmt',
            children: ifChildren
          };
        case 'WhileStatement':
          return {
            name: 'WhileStmt',
            children: [parseNode(n.condition), parseNode(n.body)]
          };
        case 'ForStatement':
          return {
            name: 'ForStmt',
            children: [
              n.init ? { name: 'Init', children: [parseNode(n.init)] } : null,
              n.condition ? { name: 'Cond', children: [parseNode(n.condition)] } : null,
              n.update ? { name: 'Update', children: [parseNode(n.update)] } : null,
              { name: 'Body', children: [parseNode(n.body)] }
            ].filter(Boolean)
          };
        case 'ReturnStatement':
          return {
            name: 'ReturnStmt',
            children: n.value ? [parseNode(n.value)] : []
          };
        case 'Identifier':
          return { name: `Ident: ${n.name}` };
        case 'Literal':
          return { name: `Literal: ${n.raw}` };
        case 'FunctionCall':
          return {
            name: `Call: ${n.name}()`,
            children: n.arguments.map(parseNode).filter(Boolean)
          };
        case 'BreakStatement':
          return { name: 'Break' };
        case 'ContinueStatement':
          return { name: 'Continue' };
        default:
          return { name: n.type || 'UnknownNode' };
      }
    };

    return parseNode(node);
  }
}

module.exports = { Parser };
