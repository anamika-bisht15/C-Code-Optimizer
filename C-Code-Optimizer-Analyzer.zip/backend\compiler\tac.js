/**
 * Three Address Code (TAC) and Quadruple Generator
 * For C-Code Optimizer and Analyzer
 */

class TacGenerator {
  constructor() {
    this.tempCount = 1;
    this.labelCount = 1;
    this.instructions = [];
    this.quadruples = []; // Each quad is { index, op, arg1, arg2, result }
  }

  newTemp() {
    return `t${this.tempCount++}`;
  }

  newLabel() {
    return `L${this.labelCount++}`;
  }

  emit(op, arg1, arg2, result) {
    const index = this.quadruples.length + 1;
    this.quadruples.push({ index, op, arg1: String(arg1), arg2: String(arg2), result: String(result) });
    
    // Generate instruction string for display
    let instrStr = '';
    if (op === '=') {
      instrStr = `${result} = ${arg1}`;
    } else if (['+', '-', '*', '/', '%', '<<', '>>', '==', '!=', '<', '<=', '>', '>=', '&&', '||'].includes(op)) {
      instrStr = `${result} = ${arg1} ${op} ${arg2}`;
    } else if (op === 'ifGoto') {
      instrStr = `if ${arg1} goto ${result}`;
    } else if (op === 'goto') {
      instrStr = `goto ${result}`;
    } else if (op === 'label') {
      instrStr = `${result}:`;
    } else if (op === 'return') {
      instrStr = arg1 ? `return ${arg1}` : 'return';
    } else if (['!', '~', 'pre-++', 'pre--', 'post-++', 'post--'].includes(op)) {
      instrStr = `${result} = ${op} ${arg1}`;
    } else if (op === 'call') {
      instrStr = `${result} = call ${arg1}(${arg2})`;
    } else if (op === 'param') {
      instrStr = `param ${arg1}`;
    } else {
      instrStr = `${result} = ${op} ${arg1} ${arg2}`;
    }
    
    this.instructions.push(instrStr);
  }

  generate(node) {
    if (!node) return '';

    switch (node.type) {
      case 'Program':
        node.body.forEach(stmt => this.generate(stmt));
        break;

      case 'FunctionDeclaration':
        this.emit('label', '', '', node.name);
        this.generate(node.body);
        break;

      case 'Block':
        node.statements.forEach(stmt => this.generate(stmt));
        break;

      case 'VariableDeclaration':
        if (node.init) {
          const val = this.generate(node.init);
          this.emit('=', val, '', node.name);
        }
        break;

      case 'Assignment': {
        const val = this.generate(node.value);
        this.emit('=', val, '', node.name);
        return node.name;
      }

      case 'ExpressionStatement':
        this.generate(node.expression);
        break;

      case 'BinaryExpression': {
        const left = this.generate(node.left);
        const right = this.generate(node.right);
        const temp = this.newTemp();
        this.emit(node.operator, left, right, temp);
        return temp;
      }

      case 'UnaryExpression': {
        const arg = this.generate(node.argument);
        const temp = this.newTemp();
        this.emit(node.operator, arg, '', temp);
        return temp;
      }

      case 'IfStatement': {
        const cond = this.generate(node.condition);
        const labelTrue = this.newLabel();
        const labelFalse = this.newLabel();
        const labelEnd = this.newLabel();

        this.emit('ifGoto', cond, '', labelTrue);
        this.emit('goto', '', '', labelFalse);

        this.emit('label', '', '', labelTrue);
        this.generate(node.thenBranch);
        this.emit('goto', '', '', labelEnd);

        this.emit('label', '', '', labelFalse);
        if (node.elseBranch) {
          this.generate(node.elseBranch);
        }
        this.emit('goto', '', '', labelEnd);

        this.emit('label', '', '', labelEnd);
        break;
      }

      case 'WhileStatement': {
        const labelStart = this.newLabel();
        const labelBody = this.newLabel();
        const labelEnd = this.newLabel();

        this.emit('label', '', '', labelStart);
        const cond = this.generate(node.condition);
        this.emit('ifGoto', cond, '', labelBody);
        this.emit('goto', '', '', labelEnd);

        this.emit('label', '', '', labelBody);
        this.generate(node.body);
        this.emit('goto', '', '', labelStart);

        this.emit('label', '', '', labelEnd);
        break;
      }

      case 'ForStatement': {
        const labelStart = this.newLabel();
        const labelBody = this.newLabel();
        const labelEnd = this.newLabel();

        if (node.init) this.generate(node.init);

        this.emit('label', '', '', labelStart);
        if (node.condition) {
          const cond = this.generate(node.condition);
          this.emit('ifGoto', cond, '', labelBody);
          this.emit('goto', '', '', labelEnd);
        } else {
          this.emit('goto', '', '', labelBody);
        }

        this.emit('label', '', '', labelBody);
        this.generate(node.body);
        
        if (node.update) this.generate(node.update);
        this.emit('goto', '', '', labelStart);

        this.emit('label', '', '', labelEnd);
        break;
      }

      case 'ReturnStatement': {
        const val = node.value ? this.generate(node.value) : '';
        this.emit('return', val, '', '');
        break;
      }

      case 'BreakStatement':
        this.emit('goto', '', '', 'BREAK_LABEL_PLACEHOLDER');
        break;

      case 'ContinueStatement':
        this.emit('goto', '', '', 'CONTINUE_LABEL_PLACEHOLDER');
        break;

      case 'Literal':
        return node.raw || String(node.value);

      case 'Identifier':
        return node.name;

      case 'FunctionCall': {
        const argsTemps = node.arguments.map(arg => this.generate(arg));
        argsTemps.forEach(arg => {
          this.emit('param', arg, '', '');
        });
        const temp = this.newTemp();
        this.emit('call', node.name, argsTemps.length, temp);
        return temp;
      }
    }
  }
}

function generateTAC(ast) {
  const gen = new TacGenerator();
  gen.generate(ast);
  return {
    instructions: gen.instructions,
    quadruples: gen.quadruples
  };
}

module.exports = { generateTAC, TacGenerator };
