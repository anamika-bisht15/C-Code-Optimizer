/**
 * API Routes for C-Code Optimizer and Analyzer
 * Coordinates the full compilation pipeline: tokenize, parse, optimize, analyze, and format.
 */

const express = require('express');
const router = express.Router();

const { tokenize } = require('../compiler/lexer');
const { Parser } = require('../compiler/parser');
const { optimizeAST, generateCode } = require('../compiler/optimizer');
const { generateTAC } = require('../compiler/tac');
const { analyzeComplexity } = require('../compiler/complexity');
const { generateAlgorithm } = require('../compiler/algorithm');
const { generateFlowchart } = require('../compiler/flowchart');

router.post('/analyze', (req, res) => {
  const { code } = req.body;

  if (typeof code !== 'string') {
    return res.status(400).json({ success: false, error: 'C code input is required' });
  }

  try {
    // 1. Lexical Analysis
    const tokens = tokenize(code);

    // 2. Syntax Analysis
    const parser = new Parser(tokens);
    const parseResult = parser.parse();

    if (parseResult.errors.length > 0) {
      return res.json({
        success: false,
        errors: parseResult.errors,
        tokens: tokens.map(t => ({ type: t.type, value: t.value, line: t.line, column: t.column }))
      });
    }

    const ast = parseResult.ast;

    // 3. Complexity Analysis (Before optimization)
    const complexity = analyzeComplexity(ast);

    // 4. Intermediate Code Generation (Before optimization)
    const originalTac = generateTAC(ast);

    // 5. Code Optimization (8 Passes)
    const optimizedAst = optimizeAST(ast);
    const optimizedCode = generateCode(optimizedAst);
    const optimizedTac = generateTAC(optimizedAst);

    // 6. Algorithm & Flowchart Generator
    const algorithm = generateAlgorithm(ast);
    const flowchart = generateFlowchart(ast);

    // Calculate Optimization Metrics
    const originalLines = code.split('\n').filter(l => l.trim().length > 0).length;
    const optimizedLines = optimizedCode.split('\n').filter(l => l.trim().length > 0).length;
    
    let reductionPercentage = 0;
    if (originalLines > 0) {
      reductionPercentage = Math.max(0, Math.round(((originalLines - optimizedLines) / originalLines) * 100));
    }

    res.json({
      success: true,
      tokens: tokens.map(t => ({ type: t.type, value: t.value, line: t.line, column: t.column })),
      parseTree: parseResult.parseTree,
      originalCode: code,
      optimizedCode: optimizedCode,
      reductionPercentage,
      originalTac: {
        instructions: originalTac.instructions,
        quadruples: originalTac.quadruples
      },
      optimizedTac: {
        instructions: optimizedTac.instructions,
        quadruples: optimizedTac.quadruples
      },
      complexity,
      algorithm,
      flowchart,
      errors: []
    });

  } catch (error) {
    console.error('Compiler execution error:', error);
    res.status(500).json({
      success: false,
      error: 'An internal error occurred during compilation/optimization: ' + error.message,
      errors: [error.message]
    });
  }
});

module.exports = router;
