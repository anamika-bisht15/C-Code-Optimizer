import React, { useState, useEffect } from 'react';
import Editor, { SAMPLES } from './components/Editor';
import LexicalPanel from './components/LexicalPanel';
import SyntaxPanel from './components/SyntaxPanel';
import TacPanel from './components/TacPanel';
import OptimizationPanel from './components/OptimizationPanel';
import ComplexityPanel from './components/ComplexityPanel';
import AlgorithmPanel from './components/AlgorithmPanel';
import { Sun, Moon, Cpu, Sparkles, AlertTriangle, CheckCircle, FileText, Download } from 'lucide-react';
import confetti from 'canvas-confetti';

const API_BASE = 'http://localhost:5000/api';

export default function App() {
  const [code, setCode] = useState(SAMPLES.all);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [theme, setTheme] = useState('dark');
  const [activeTab, setActiveTab] = useState('OPTIMIZATION'); // OPTIMIZATION, LEXICAL, SYNTAX, TAC, COMPLEXITY, FLOWCHART

  // Toggle Dark Mode class on body
  useEffect(() => {
    const root = window.document.body;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE}/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
      });
      const data = await response.json();
      
      if (data.success) {
        setResult(data);
        // Show success animation confetti if there is optimization reduction
        if (data.reductionPercentage > 0) {
          confetti({
            particleCount: 80,
            spread: 60,
            origin: { y: 0.8 }
          });
        }
      } else {
        setError(data.errors || ['Failed to compile. Please check your C syntax.']);
        setResult(null);
      }
    } catch (err) {
      console.error(err);
      setError(['Could not connect to the compilation server. Please ensure the backend Node Express server is running on port 5000.']);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDownloadPdf = async () => {
    try {
      const response = await fetch(`${API_BASE}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate PDF');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'C-Code-Optimization-Report.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('PDF Download failed', err);
      alert('Could not download PDF report. Ensure the backend server is running.');
    }
  };

  // Run initial analysis on start
  useEffect(() => {
    handleAnalyze();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0b0f19] text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-all duration-300">
      
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/70 dark:bg-[#0b0f19]/70 backdrop-blur-md border-b border-slate-200/50 dark:border-slate-800/80 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-gradient-to-tr from-sky-500 to-indigo-600 rounded-xl text-white shadow-md shadow-sky-500/20">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-extrabold tracking-tight bg-gradient-to-r from-sky-500 to-indigo-500 bg-clip-text text-transparent">
              C-CODE OPTIMIZER & ANALYZER
            </h1>
            <p className="text-[10px] uppercase font-bold tracking-widest text-slate-400 dark:text-slate-500">
              Compiler Design Final Year Project
            </p>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleDownloadPdf}
            className="flex items-center space-x-1.5 text-xs font-semibold px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-650 dark:text-slate-350 cursor-pointer shadow-sm transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Report</span>
          </button>
          
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all text-slate-550 dark:text-slate-400 cursor-pointer shadow-sm"
          >
            {theme === 'dark' ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="flex-1 p-6 grid grid-cols-1 xl:grid-cols-12 gap-6 items-stretch">
        
        {/* Editor Area (Left 5 Cols) */}
        <section className="xl:col-span-5 flex flex-col h-[calc(100vh-140px)] min-h-[500px]">
          <div className="glass-card flex-1 flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-md font-bold text-slate-800 dark:text-slate-200">Source C Code</h2>
                <p className="text-xs text-slate-500 dark:text-slate-450">Write or drag C code to optimize.</p>
              </div>
            </div>
            
            <div className="flex-1 h-0">
              <Editor 
                code={code} 
                setCode={setCode} 
                onAnalyze={handleAnalyze} 
                isAnalyzing={isAnalyzing} 
              />
            </div>
          </div>
        </section>

        {/* Dashboard Panels Area (Right 7 Cols) */}
        <section className="xl:col-span-7 flex flex-col h-[calc(100vh-140px)] min-h-[500px]">
          <div className="glass-card flex-1 flex flex-col h-full">
            
            {/* Tabs List */}
            <nav className="flex flex-wrap border-b border-slate-200 dark:border-slate-800 pb-3 mb-4 gap-1.5 select-none">
              {[
                { id: 'OPTIMIZATION', label: 'Code Optimization' },
                { id: 'LEXICAL', label: 'Lexical Analysis' },
                { id: 'SYNTAX', label: 'Syntax (AST)' },
                { id: 'TAC', label: 'TAC & Quads' },
                { id: 'FLOWCHART', label: 'Flowchart & Algo' },
                { id: 'COMPLEXITY', label: 'Complexity' }
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`text-xs font-bold px-3.5 py-2 rounded-xl transition-all cursor-pointer ${
                    activeTab === t.id
                      ? 'bg-sky-500 text-white shadow-md shadow-sky-500/10'
                      : 'bg-slate-100 dark:bg-slate-900 text-slate-500 hover:text-slate-700 dark:hover:text-slate-350 border border-slate-200/40 dark:border-slate-800/40'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </nav>

            {/* Error notifications */}
            {error && (
              <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-950/40 p-4 rounded-2xl mb-4 flex items-start space-x-3 text-red-650 dark:text-red-400">
                <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-bold">Compilation Errors Encountered</p>
                  <ul className="list-disc pl-4 text-xs space-y-1 font-mono">
                    {error.map((err, i) => <li key={i}>{err}</li>)}
                  </ul>
                </div>
              </div>
            )}

            {/* Tab Panels Contents */}
            <div className="flex-1 h-0 overflow-y-auto pr-1">
              {activeTab === 'OPTIMIZATION' && (
                <OptimizationPanel 
                  originalCode={code}
                  optimizedCode={result?.optimizedCode}
                  reductionPercentage={result?.reductionPercentage}
                />
              )}

              {activeTab === 'LEXICAL' && (
                <LexicalPanel tokens={result?.tokens} />
              )}

              {activeTab === 'SYNTAX' && (
                <SyntaxPanel parseTree={result?.parseTree} />
              )}

              {activeTab === 'TAC' && (
                <TacPanel 
                  originalTac={result?.originalTac} 
                  optimizedTac={result?.optimizedTac} 
                />
              )}

              {activeTab === 'FLOWCHART' && (
                <AlgorithmPanel 
                  algorithm={result?.algorithm} 
                  flowchart={result?.flowchart}
                  onDownloadPdf={handleDownloadPdf}
                />
              )}

              {activeTab === 'COMPLEXITY' && (
                <ComplexityPanel complexity={result?.complexity} />
              )}
            </div>

          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="py-4 border-t border-slate-200/50 dark:border-slate-800/80 px-6 flex justify-between items-center text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest font-bold">
        <span>Final Year Compiler Project</span>
        <span>Made with Antigravity AI Engine</span>
      </footer>

    </div>
  );
}
