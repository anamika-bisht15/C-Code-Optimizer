import React, { useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';
import { ClipboardList, Image, FileImage, Download, RefreshCw, FileText } from 'lucide-react';

// Initialize mermaid configurations
mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'loose',
  flowchart: {
    useMaxWidth: true,
    htmlLabels: true
  }
});

export default function AlgorithmPanel({ algorithm, flowchart, onDownloadPdf }) {
  const [svgContent, setSvgContent] = useState('');
  const [renderError, setRenderError] = useState(null);
  const containerRef = useRef(null);

  useEffect(() => {
    if (!flowchart || !flowchart.mermaid) return;
    
    const renderFlowchart = async () => {
      try {
        setRenderError(null);
        // Clear container first
        if (containerRef.current) {
          containerRef.current.innerHTML = '';
        }
        
        const uniqueId = `mermaid-${Date.now()}`;
        const { svg } = await mermaid.render(uniqueId, flowchart.mermaid);
        setSvgContent(svg);
        if (containerRef.current) {
          containerRef.current.innerHTML = svg;
        }
      } catch (err) {
        console.error('Mermaid render error:', err);
        setRenderError('Failed to render flowchart. Syntax is valid but layout algorithm errored.');
      }
    };

    renderFlowchart();
  }, [flowchart]);

  if (!algorithm || algorithm.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
        <ClipboardList className="w-12 h-12 mb-3 text-slate-300 dark:text-slate-700 animate-pulse" />
        <p className="text-sm">Run analysis to generate algorithm & flowchart.</p>
      </div>
    );
  }

  // --- Export Handlers ---
  const handleExportSvg = () => {
    if (!svgContent) return;
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'program-flowchart.svg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportPng = () => {
    if (!svgContent) return;

    // Create a virtual canvas to convert SVG to PNG
    const svgElement = containerRef.current.querySelector('svg');
    if (!svgElement) return;

    const svgString = new XMLSerializer().serializeToString(svgElement);
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const URL = window.URL || window.webkitURL || window;
    const blobURL = URL.createObjectURL(svgBlob);

    const image = new window.Image();
    // Get dimensions
    const width = svgElement.viewBox.baseVal.width || 800;
    const height = svgElement.viewBox.baseVal.height || 600;

    image.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width * 2; // double size for crisp resolution
      canvas.height = height * 2;
      const context = canvas.getContext('2d');
      context.scale(2, 2);
      
      // Draw background (white/transparent)
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, width, height);
      
      context.drawImage(image, 0, 0, width, height);
      
      const pngURL = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngURL;
      downloadLink.download = 'program-flowchart.png';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(blobURL);
    };

    image.src = blobURL;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
      {/* Step-by-Step Algorithm */}
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between items-center px-1">
          <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            Step-by-Step Algorithm
          </h3>
        </div>
        <div className="flex-1 overflow-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-3.5">
          {algorithm.map((step, idx) => (
            <div 
              key={idx}
              className="flex items-start space-x-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors border border-slate-100/50 dark:border-slate-800/50"
            >
              <span className="flex items-center justify-center shrink-0 w-16 px-2 py-1 text-xs font-bold font-mono text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/40 rounded-lg">
                {step.step}
              </span>
              <p className="text-sm text-slate-700 dark:text-slate-250 leading-relaxed font-medium">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Program Flowchart */}
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between items-center px-1">
          <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            Interactive Flowchart
          </h3>
          {/* Export buttons */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handleExportSvg}
              className="flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-650 dark:text-slate-350 cursor-pointer shadow-sm"
              title="Export as SVG"
            >
              <FileImage className="w-3.5 h-3.5" />
              <span>SVG</span>
            </button>
            <button
              onClick={handleExportPng}
              className="flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-650 dark:text-slate-350 cursor-pointer shadow-sm"
              title="Export as PNG"
            >
              <Image className="w-3.5 h-3.5" />
              <span>PNG</span>
            </button>
            <button
              onClick={onDownloadPdf}
              className="flex items-center space-x-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 hover:bg-indigo-100 text-indigo-600 dark:text-indigo-400 cursor-pointer shadow-sm"
              title="Export as PDF Report"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>PDF Report</span>
            </button>
          </div>
        </div>

        <div className="flex-1 min-h-[400px] overflow-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col items-center justify-center relative shadow-sm">
          {renderError ? (
            <div className="text-center space-y-2">
              <p className="text-sm text-red-500 font-semibold">{renderError}</p>
              <button 
                onClick={() => setSvgContent(svgContent)} 
                className="text-xs text-sky-500 font-bold hover:underline flex items-center justify-center space-x-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Retry Rendering</span>
              </button>
            </div>
          ) : (
            // Mermaid output container
            <div 
              ref={containerRef} 
              className="w-full h-full flex items-center justify-center overflow-auto scale-95 origin-center transition-transform hover:scale-100 duration-300"
            />
          )}
        </div>
      </div>
    </div>
  );
}
