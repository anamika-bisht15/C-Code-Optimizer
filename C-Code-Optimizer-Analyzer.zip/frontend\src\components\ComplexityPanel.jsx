import React from 'react';
import { Gauge, Layers, RefreshCw, HelpCircle, Variable, Server } from 'lucide-react';

export default function ComplexityPanel({ complexity }) {
  if (!complexity) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
        <Gauge className="w-12 h-12 mb-3 text-slate-300 dark:text-slate-700 animate-pulse" />
        <p className="text-sm">Run analysis to view program complexity metrics.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full space-y-6">
      {/* Big-O Badges */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Time Complexity Card */}
        <div className="bg-gradient-to-br from-indigo-50 to-indigo-100/50 dark:from-indigo-950/20 dark:to-slate-900 border border-indigo-100 dark:border-indigo-950/50 p-6 rounded-2xl flex items-center justify-between shadow-sm">
          <div className="space-y-1">
            <span className="text-xs font-bold text-indigo-500 uppercase tracking-wider">Estimated Time Complexity</span>
            <h3 className="text-4xl font-extrabold text-indigo-650 dark:text-indigo-400 font-mono">
              {complexity.timeComplexity}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Calculated from loop nesting & updates.</p>
          </div>
          <Gauge className="w-12 h-12 text-indigo-500/80" />
        </div>

        {/* Space Complexity Card */}
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 dark:from-emerald-950/20 dark:to-slate-900 border border-emerald-100 dark:border-emerald-950/50 p-6 rounded-2xl flex items-center justify-between shadow-sm">
          <div className="space-y-1">
            <span className="text-xs font-bold text-emerald-500 uppercase tracking-wider">Estimated Space Complexity</span>
            <h3 className="text-4xl font-extrabold text-emerald-650 dark:text-emerald-400 font-mono">
              {complexity.spaceComplexity}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Stack frames & variables allocation.</p>
          </div>
          <Server className="w-12 h-12 text-emerald-500/80" />
        </div>
      </div>

      {/* Metrics Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Loops count */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl text-amber-500">
            <RefreshCw className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Total Loops</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-slate-100">{complexity.loopCount}</p>
          </div>
        </div>

        {/* Loop Nesting Depth */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-rose-50 dark:bg-rose-950/30 rounded-xl text-rose-500">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Max Loop Nesting</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-slate-100">{complexity.maxNestingDepth}</p>
          </div>
        </div>

        {/* Recursion Status */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex items-center space-x-4">
          <div className={`p-3 rounded-xl ${
            complexity.recursionDetected 
              ? 'bg-rose-100 dark:bg-rose-950/40 text-rose-500' 
              : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
          }`}>
            <HelpCircle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <p className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Recursion</p>
            <p className={`text-lg font-extrabold ${
              complexity.recursionDetected ? 'text-rose-500' : 'text-slate-500'
            }`}>
              {complexity.recursionDetected ? 'DETECTED' : 'NONE DETECTED'}
            </p>
          </div>
        </div>
      </div>

      {/* Function Analysis List */}
      <div className="flex-1 space-y-4">
        <h4 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider px-1">
          Function-level Metrics
        </h4>
        <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
          {complexity.functions && complexity.functions.length > 0 ? (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-55 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <th className="py-3.5 px-5">Function Name</th>
                  <th className="py-3.5 px-5">Variables</th>
                  <th className="py-3.5 px-5">Loops</th>
                  <th className="py-3.5 px-5">Max Nesting</th>
                  <th className="py-3.5 px-5">Recursion</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/65 text-sm">
                {complexity.functions.map((f, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="py-3 px-5 font-mono font-bold text-indigo-650 dark:text-indigo-400">{f.name}()</td>
                    <td className="py-3 px-5 text-slate-600 dark:text-slate-300">{f.variablesCount} variables</td>
                    <td className="py-3 px-5 text-slate-600 dark:text-slate-300">{f.loopCount} loops</td>
                    <td className="py-3 px-5 text-slate-600 dark:text-slate-300">{f.maxNesting} levels</td>
                    <td className="py-3 px-5">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                        f.hasRecursion
                          ? 'bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400'
                          : 'bg-slate-100 dark:bg-slate-850 text-slate-400 dark:text-slate-500'
                      }`}>
                        {f.hasRecursion ? 'Yes' : 'No'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="py-8 text-center text-slate-400 dark:text-slate-500 text-sm">
              No custom functions defined in this code. Analysis done on global scope.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
