import React, { useState } from 'react';
import MonacoEditor from '@monaco-editor/react';
import { Upload, FileCode, Play, Sparkles } from 'lucide-react';

const SAMPLES = {
  all: `// Demo: All compiler optimization passes
int main() {
    int x = 10 + 5;           // Constant Folding
    int y = x;                // Copy Propagation
    int z = y * 2;            // Strength Reduction
    int unused = 40;          // Unused Variable
    
    // Common Subexpression Elimination
    int a = x + z;
    int b = x + z;
    
    // Loop Invariant Code Motion
    int i = 0;
    int sum = 0;
    while (i < 10) {
        int invariant = 100 * 2;
        sum = sum + invariant + i;
        i = i + 1;
    }
    
    if (0) {                  // Dead Code Elimination
        sum = sum + 999;
    }
    
    return sum + a + b;
}`,
  folding: `// Demo: Constant Folding
int main() {
    int a = 10 + 20 * 30; // Fold values
    float pi = 3.1415 + 0.0001;
    int x = 2 << 3;
    int y = 5 % 2;
    int truth = (10 > 5) && (2 < 4);
    return a;
}`,
  propagation: `// Demo: Constant & Copy Propagation
int main() {
    int x = 42;
    int y = x;
    int z = y;
    int sum = z + y + x;
    return sum;
}`,
  dead_code: `// Demo: Dead Code Elimination
int main() {
    int flag = 0;
    int val = 100;
    
    if (flag) {
        val = val * 5;
    } else {
        val = val + 5;
    }
    
    if (0) {
        val = 999; // Reachable? No.
    }
    
    return val;
}`,
  cse: `// Demo: Common Subexpression Elimination
int main() {
    int x = a + b;
    int y = a + b;
    int z = (a + b) * 2;
    return x + y + z;
}`,
  loop: `// Demo: Loop Invariant Code Motion
int main() {
    int i = 0;
    int sum = 0;
    int a = 5;
    int b = 10;
    
    while (i < 100) {
        // x = a * b is invariant inside loop
        int x = a * b;
        sum = sum + x + i;
        i = i + 1;
    }
    
    return sum;
}`,
  strength: `// Demo: Strength Reduction
int main() {
    int x = val * 2;
    int y = val * 8;
    int z = val / 2;
    int w = val * 0;
    int u = val * 1;
    return x + y + z;
}`
};

export default function Editor({ code, setCode, onAnalyze, isAnalyzing }) {
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        setCode(event.target.result);
      };
      reader.readAsText(file);
    }
  };

  const handleFileUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        setCode(event.target.result);
      };
      reader.readAsText(file);
    }
  };

  const loadPreset = (preset) => {
    if (SAMPLES[preset]) {
      setCode(SAMPLES[preset]);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Preset toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/80">
        <div className="flex items-center space-x-2">
          <FileCode className="w-5 h-5 text-sky-500" />
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Presets</span>
          <select 
            onChange={(e) => loadPreset(e.target.value)}
            className="text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800 dark:text-slate-200 transition-all cursor-pointer"
            defaultValue="all"
          >
            <option value="all">Full Optimization Demo</option>
            <option value="folding">Constant Folding</option>
            <option value="propagation">Constant & Copy Propagation</option>
            <option value="dead_code">Dead Code Elimination</option>
            <option value="cse">Common Subexpression</option>
            <option value="loop">Loop Invariant Motion</option>
            <option value="strength">Strength Reduction</option>
          </select>
        </div>

        <button
          onClick={onAnalyze}
          disabled={isAnalyzing}
          className="flex items-center space-x-2 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white font-medium text-sm py-2 px-5 rounded-lg shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-sky-400 disabled:opacity-50 transition-all shrink-0 cursor-pointer"
        >
          {isAnalyzing ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Analyzing...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" />
              <span>Optimize & Analyze</span>
            </>
          )}
        </button>
      </div>

      {/* Editor & Drag and Drop Zone */}
      <div 
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        className={`relative flex-1 rounded-2xl overflow-hidden border-2 transition-all ${
          dragActive 
            ? 'border-sky-500 bg-sky-500/5 shadow-inner scale-[0.99]' 
            : 'border-slate-200 dark:border-slate-800 shadow-sm'
        }`}
      >
        <MonacoEditor
          height="100%"
          language="c"
          theme="vs-dark"
          value={code}
          onChange={(val) => setCode(val || '')}
          options={{
            fontSize: 14,
            minimap: { enabled: false },
            automaticLayout: true,
            scrollBeyondLastLine: false,
            padding: { top: 12, bottom: 12 },
            cursorBlinking: 'smooth',
            cursorSmoothCaretAnimation: 'on',
            lineNumbersMinChars: 3
          }}
        />

        {/* Drag overlay */}
        {dragActive && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-sky-500/10 backdrop-blur-sm pointer-events-none transition-all duration-200">
            <div className="flex flex-col items-center space-y-3 bg-white dark:bg-slate-900 border border-sky-400 p-6 rounded-2xl shadow-xl animate-pulse">
              <Upload className="w-10 h-10 text-sky-500" />
              <p className="text-sm font-semibold text-sky-500">Drop C file here to upload</p>
            </div>
          </div>
        )}
      </div>

      {/* Upload button alternative */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
        <span>Drag & drop a C file into editor, or</span>
        <label className="flex items-center space-x-1 text-sky-500 hover:text-sky-600 font-semibold cursor-pointer transition-colors">
          <Upload className="w-3.5 h-3.5" />
          <span>Browse File</span>
          <input 
            type="file" 
            accept=".c,.cpp,.txt,.h" 
            onChange={handleFileUpload} 
            className="hidden" 
          />
        </label>
      </div>
    </div>
  );
}
export { SAMPLES };
