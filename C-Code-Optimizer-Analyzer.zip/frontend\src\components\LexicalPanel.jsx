import React, { useState } from 'react';
import { Search, Eye } from 'lucide-react';

export default function LexicalPanel({ tokens }) {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  if (!tokens || tokens.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
        <Eye className="w-12 h-12 mb-3 text-slate-300 dark:text-slate-700 animate-pulse" />
        <p className="text-sm">Run analysis to view lexical tokens table.</p>
      </div>
    );
  }

  // Extract unique token types for filtering
  const tokenTypes = ['ALL', ...new Set(tokens.map(t => t.type))];

  // Filter token list based on search and type filter
  const filteredTokens = tokens.filter(t => {
    const matchesSearch = t.value.toLowerCase().includes(search.toLowerCase()) || 
                          t.type.toLowerCase().includes(search.toLowerCase());
    const matchesType = filterType === 'ALL' || t.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Search & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-1">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search tokens..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800 dark:text-slate-200 transition-all shadow-sm"
          />
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-500 font-medium">Filter Type:</span>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800 dark:text-slate-200 transition-all cursor-pointer shadow-sm"
          >
            {tokenTypes.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Token Table */}
      <div className="flex-1 overflow-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-inner">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider sticky top-0 border-b border-slate-200 dark:border-slate-800 backdrop-blur-md">
              <th className="py-3 px-4">Index</th>
              <th className="py-3 px-4">Lexeme</th>
              <th className="py-3 px-4">Token Type</th>
              <th className="py-3 px-4">Line</th>
              <th className="py-3 px-4">Column</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-sm">
            {filteredTokens.length > 0 ? (
              filteredTokens.map((token, index) => (
                <tr 
                  key={index} 
                  className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                >
                  <td className="py-2.5 px-4 text-slate-400 font-mono text-xs">{index + 1}</td>
                  <td className="py-2.5 px-4 font-mono font-medium text-slate-800 dark:text-slate-100">
                    <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200/40 dark:border-slate-700/40">
                      {token.value}
                    </span>
                  </td>
                  <td className="py-2.5 px-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      token.type === 'KEYWORD' ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' :
                      token.type === 'OPERATOR' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400' :
                      token.type === 'NUMBER' ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400' :
                      token.type === 'IDENTIFIER' ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400' :
                      token.type === 'COMMENT' ? 'bg-slate-100 dark:bg-slate-800 text-slate-450 dark:text-slate-400 italic' :
                      'bg-slate-50 dark:bg-slate-800/30 text-slate-500'
                    }`}>
                      {token.type}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-xs text-slate-500">{token.line}</td>
                  <td className="py-2.5 px-4 font-mono text-xs text-slate-500">{token.column}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="py-8 text-center text-slate-400 dark:text-slate-500">
                  No tokens match search criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex justify-between items-center px-1 text-xs text-slate-400">
        <span>Total Tokens: {tokens.length}</span>
        <span>Filtered Tokens: {filteredTokens.length}</span>
      </div>
    </div>
  );
}
