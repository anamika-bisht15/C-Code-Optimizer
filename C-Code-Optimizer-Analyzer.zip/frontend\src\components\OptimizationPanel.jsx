import React from 'react';
import { DiffEditor } from '@monaco-editor/react';
import { Sparkles, ArrowRight, Zap, Shrink, FileCode } from 'lucide-react';

export default function OptimizationPanel({ originalCode, optimizedCode, reductionPercentage }) {
  if (!optimizedCode) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
        <Zap className="w-12 h-12 mb-3 text-slate-300 dark:text-slate-700 animate-pulse" />
        <p className="text-sm">Run analysis to view side-by-side C code optimizations.</p>
      </div>
    );
  }

  const originalLines = originalCode.split('\n').filter(Boolean).length;
  const optimizedLines = optimizedCode.split('\n').filter(Boolean).length;
  const linesSaved = Math.max(0, originalLines - optimizedLines);

  return (
    <div className="flex flex-col h-full space-y-5">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Metric 1: Size Reduction */}
        <div className="relative overflow-hidden bg-gradient-to-br from-sky-500 to-indigo-600 p-5 rounded-2xl text-white shadow-md">
          <div className="absolute right-3 bottom-1 opacity-10">
            <Shrink className="w-28 h-28" />
          </div>
          <p className="text-xs uppercase font-bold tracking-wider opacity-75">Code Size Reduction</p>
          <div className="flex items-baseline space-x-2 mt-2">
            <span className="text-4xl font-extrabold">{reductionPercentage}%</span>
            <span className="text-sm font-semibold opacity-90">fewer lines</span>
          </div>
          <p className="text-xs mt-3 opacity-90 font-medium">Optimization runs successful</p>
        </div>

        {/* Metric 2: Line Stats */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-center text-slate-400 dark:text-slate-500">
            <span className="text-xs uppercase font-bold tracking-wider">Line Count</span>
            <FileCode className="w-4 h-4 text-sky-500" />
          </div>
          <div className="flex items-center space-x-3 mt-2">
            <div className="text-2xl font-bold text-slate-800 dark:text-slate-100">{originalLines}</div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
            <div className="text-2xl font-bold text-emerald-500">{optimizedLines}</div>
          </div>
          <p className="text-xs mt-3 text-slate-500 dark:text-slate-400">
            Saved <span className="font-bold text-emerald-500">{linesSaved}</span> redundant code lines.
          </p>
        </div>

        {/* Metric 3: Optimization passes */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-center text-slate-400 dark:text-slate-500">
            <span className="text-xs uppercase font-bold tracking-wider">Passes Configured</span>
            <Sparkles className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-800 dark:text-slate-100">8 passes</div>
          <p className="text-xs mt-3 text-slate-500 dark:text-slate-400">
            Constant Folding, Propagations, Dead Code, CSE, etc.
          </p>
        </div>
      </div>

      {/* Editor Headers */}
      <div className="flex justify-between text-xs font-semibold text-slate-400 dark:text-slate-500 px-2 select-none">
        <span>ORIGINAL SOURCE CODE</span>
        <span>OPTIMIZED C-CODE (AST TRANSFORMED)</span>
      </div>

      {/* Diff Editor Container */}
      <div className="flex-1 min-h-[350px] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-inner">
        <DiffEditor
          original={originalCode}
          modified={optimizedCode}
          language="c"
          theme="vs-dark"
          options={{
            fontSize: 14,
            readOnly: true,
            minimap: { enabled: false },
            automaticLayout: true,
            scrollBeyondLastLine: false,
            renderSideBySide: true,
            padding: { top: 12, bottom: 12 }
          }}
        />
      </div>
    </div>
  );
}
