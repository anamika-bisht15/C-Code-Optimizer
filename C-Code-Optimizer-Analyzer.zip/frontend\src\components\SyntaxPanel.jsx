import React, { useState } from 'react';
import { Network, Folder, FolderOpen, Terminal, Code, Info } from 'lucide-react';

// Recursive Collapsible Tree Node Component
function TreeNode({ node, depth = 0 }) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = node.children && node.children.length > 0;

  const toggleOpen = () => setIsOpen(!isOpen);

  // Icon selector based on node name
  const getIcon = () => {
    if (node.name.startsWith('FnDecl')) return <Code className="w-4 h-4 text-purple-500" />;
    if (node.name.startsWith('VarDecl')) return <Terminal className="w-4 h-4 text-sky-500" />;
    if (node.name.startsWith('Assign')) return <Terminal className="w-4 h-4 text-amber-500" />;
    if (node.name.includes('Expr')) return <Terminal className="w-4 h-4 text-emerald-500" />;
    if (node.name.includes('Stmt')) return <Network className="w-4 h-4 text-rose-500" />;
    return <Folder className="w-4 h-4 text-slate-400" />;
  };

  return (
    <div className="pl-4 border-l border-slate-200 dark:border-slate-800 ml-2">
      <div 
        onClick={hasChildren ? toggleOpen : undefined}
        className={`flex items-center space-x-2 py-1 px-2 rounded-lg cursor-pointer transition-colors ${
          hasChildren ? 'hover:bg-slate-100 dark:hover:bg-slate-800/50' : 'cursor-default'
        }`}
      >
        {hasChildren ? (
          isOpen ? (
            <FolderOpen className="w-4 h-4 text-sky-500" />
          ) : (
            <Folder className="w-4 h-4 text-sky-500" />
          )
        ) : (
          getIcon()
        )}
        <span className={`text-sm font-mono ${
          node.name.startsWith('FnDecl') ? 'text-purple-600 dark:text-purple-400 font-semibold' :
          node.name.startsWith('VarDecl') ? 'text-sky-600 dark:text-sky-400' :
          node.name.startsWith('Assign') ? 'text-amber-600 dark:text-amber-400' :
          'text-slate-700 dark:text-slate-350'
        }`}>
          {node.name}
        </span>
      </div>

      {hasChildren && isOpen && (
        <div className="mt-1 space-y-1">
          {node.children.map((child, idx) => (
            <TreeNode key={idx} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

// Simple Graphical Tree Node layout helper for SVG render
function renderSvgTree(node, x, y, spacingX, spacingY, parentX = null, parentY = null, elements = []) {
  if (!node) return elements;

  const nodeId = `node_${x}_${y}`;
  
  // Draw link from parent
  if (parentX !== null && parentY !== null) {
    elements.push(
      <path
        key={`link_${nodeId}`}
        d={`M ${parentX} ${parentY} C ${parentX} ${(parentY + y)/2}, ${x} ${(parentY + y)/2}, ${x} ${y}`}
        fill="none"
        stroke="#cbd5e1"
        strokeWidth="1.5"
        className="dark:stroke-slate-800 transition-all"
      />
    );
  }

  // Draw node node circles
  let nodeColor = '#3b82f6'; // blue
  if (node.name.startsWith('FnDecl')) nodeColor = '#a855f7'; // purple
  else if (node.name.startsWith('VarDecl')) nodeColor = '#0ea5e9'; // sky
  else if (node.name.startsWith('Assign')) nodeColor = '#f59e0b'; // amber
  else if (node.name.includes('Stmt')) nodeColor = '#f43f5e'; // rose

  elements.push(
    <g key={`group_${nodeId}`} className="group cursor-pointer">
      <circle
        cx={x}
        cy={y}
        r="6"
        fill={nodeColor}
        className="transition-all duration-300 group-hover:r-8"
      />
      <text
        x={x + 10}
        y={y + 4}
        className="text-[9px] font-mono fill-slate-600 dark:fill-slate-400 select-none pointer-events-none font-medium"
      >
        {node.name.split(':')[0]}
      </text>
    </g>
  );

  if (node.children && node.children.length > 0) {
    const childSpacing = spacingX / Math.max(1, node.children.length - 1 || 1);
    const startX = x - spacingX / 2;
    node.children.forEach((child, idx) => {
      const childX = node.children.length === 1 ? x : startX + idx * childSpacing;
      const childY = y + spacingY;
      renderSvgTree(child, childX, childY, spacingX * 0.5, spacingY, x, y, elements);
    });
  }

  return elements;
}

export default function SyntaxPanel({ parseTree }) {
  const [viewMode, setViewMode] = useState('EXPLORER'); // EXPLORER, GRAPH

  if (!parseTree) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
        <Network className="w-12 h-12 mb-3 text-slate-300 dark:text-slate-700 animate-pulse" />
        <p className="text-sm">Run analysis to generate C Syntax AST Tree.</p>
      </div>
    );
  }

  // Render SVG elements
  const svgElements = [];
  if (viewMode === 'GRAPH') {
    renderSvgTree(parseTree, 350, 40, 260, 60, null, null, svgElements);
  }

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* View Toggle */}
      <div className="flex justify-between items-center p-1">
        <div className="flex space-x-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
          <button
            onClick={() => setViewMode('EXPLORER')}
            className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              viewMode === 'EXPLORER' 
                ? 'bg-white dark:bg-slate-800 text-sky-500 shadow-sm' 
                : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-350'
            }`}
          >
            AST Explorer
          </button>
          <button
            onClick={() => setViewMode('GRAPH')}
            className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              viewMode === 'GRAPH' 
                ? 'bg-white dark:bg-slate-800 text-sky-500 shadow-sm' 
                : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-350'
            }`}
          >
            AST Graph Visualizer
          </button>
        </div>
        <div className="flex items-center space-x-1.5 text-xs text-slate-400">
          <Info className="w-3.5 h-3.5" />
          <span>Interactive view</span>
        </div>
      </div>

      {/* Content Panel */}
      <div className="flex-1 overflow-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
        {viewMode === 'EXPLORER' ? (
          <div className="space-y-1">
            <TreeNode node={parseTree} />
          </div>
        ) : (
          <div className="min-w-[700px] h-[550px] relative overflow-auto flex items-center justify-center">
            <svg 
              width="100%" 
              height="100%" 
              viewBox="0 0 700 500" 
              className="w-full h-full max-h-[500px]"
            >
              {svgElements}
            </svg>
          </div>
        )}
      </div>
    </div>
  );
}
