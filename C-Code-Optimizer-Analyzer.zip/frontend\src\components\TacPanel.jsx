import React, { useState } from 'react';
import { Layers, Terminal, ListCollapse } from 'lucide-react';

export default function TacPanel({ originalTac, optimizedTac }) {
  const [activeTab, setActiveTab] = useState('ORIGINAL'); // ORIGINAL, OPTIMIZED
  const [viewType, setViewType] = useState('CODE'); // CODE, QUAD

  const tac = activeTab === 'ORIGINAL' ? originalTac : optimizedTac;

  if (!tac || !tac.instructions || tac.instructions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
        <Layers className="w-12 h-12 mb-3 text-slate-300 dark:text-slate-700 animate-pulse" />
        <p className="text-sm">Run analysis to generate Intermediate Three Address Code (TAC).</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Toolbars */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-1">
        {/* Toggle between Original and Optimized TAC */}
        <div className="flex space-x-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
          <button
            onClick={() => setActiveTab('ORIGINAL')}
            className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'ORIGINAL'
                ? 'bg-white dark:bg-slate-800 text-sky-500 shadow-sm'
                : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-350'
            }`}
          >
            Pre-Optimization TAC
          </button>
          {optimizedTac && optimizedTac.instructions && (
            <button
              onClick={() => setActiveTab('OPTIMIZED')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'OPTIMIZED'
                  ? 'bg-white dark:bg-slate-800 text-sky-500 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-350'
              }`}
            >
              Post-Optimization TAC
            </button>
          )}
        </div>

        {/* Toggle between Code view and Quadruple Table view */}
        <div className="flex space-x-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200/50 dark:border-slate-800/50">
          <button
            onClick={() => setViewType('CODE')}
            className={`flex items-center space-x-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              viewType === 'CODE'
                ? 'bg-white dark:bg-slate-800 text-sky-500 shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>TAC Code</span>
          </button>
          <button
            onClick={() => setViewType('QUAD')}
            className={`flex items-center space-x-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              viewType === 'QUAD'
                ? 'bg-white dark:bg-slate-800 text-sky-500 shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <ListCollapse className="w-3.5 h-3.5" />
            <span>Quadruples Table</span>
          </button>
        </div>
      </div>

      {/* Main TAC Display */}
      <div className="flex-1 min-h-[350px] overflow-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
        {viewType === 'CODE' ? (
          <div className="p-5 font-mono text-sm leading-relaxed text-slate-800 dark:text-slate-200">
            {tac.instructions.map((instr, idx) => (
              <div 
                key={idx} 
                className={`py-1.5 px-3 rounded-lg flex items-center hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors ${
                  instr.endsWith(':') ? 'text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-500/5 mt-3 border-l-2 border-indigo-500 pl-2' : ''
                }`}
              >
                <span className="w-8 text-xs font-mono text-slate-450 dark:text-slate-550 select-none">
                  {(idx + 1).toString().padStart(2, '0')}
                </span>
                <span>{instr}</span>
              </div>
            ))}
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider sticky top-0 border-b border-slate-200 dark:border-slate-800 backdrop-blur-md">
                <th className="py-3 px-4">Index</th>
                <th className="py-3 px-4">Operator</th>
                <th className="py-3 px-4">Arg 1</th>
                <th className="py-3 px-4">Arg 2</th>
                <th className="py-3 px-4">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-xs">
              {tac.quadruples.map((q, idx) => (
                <tr 
                  key={idx} 
                  className={`hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors ${
                    q.op === 'label' ? 'bg-indigo-500/5 text-indigo-600 dark:text-indigo-400 font-semibold' : ''
                  }`}
                >
                  <td className="py-3 px-4 text-slate-400">({q.index})</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex px-1.5 py-0.5 rounded text-xs ${
                      q.op === 'label' ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' :
                      ['ifGoto', 'goto'].includes(q.op) ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400' :
                      q.op === '=' ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-350' :
                      'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400'
                    }`}>
                      {q.op}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{q.arg1 || '-'}</td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{q.arg2 || '-'}</td>
                  <td className="py-3 px-4 text-slate-900 dark:text-slate-100 font-bold">{q.result || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
